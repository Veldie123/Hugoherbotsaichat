# Frontend Fixes voor Andere Replit

Dit document beschrijft alle issues die gefixed moeten worden in de andere Replit.

---

## Issue 1: "Kleur groen" in Koopklok

**Probleem:** De Koopklok toont "Kleur groen" in plaats van de stage naam.

**Oorzaak:** De frontend heeft een eigen mapping die niet overeenkomt met de backend data.

**Backend stuurt:**
```json
{
  "buying_clock_stage": "market_research"
}
```

**Frontend zou moeten tonen:**
- `situation_as_is` → "00u–06u: Huidige situatie"
- `field_of_tension` → "06u–08u: Spanningsveld"
- `market_research` → "08u–11u: Marktonderzoek"
- `hesitation` → "11u–12u: Twijfel"
- `decision` → "12u: Beslissing"

**Fix:** Zoek waar "Kleur groen" staat en vervang door correcte mapping:
```typescript
const buyingClockToDisplay: Record<string, string> = {
  situation_as_is: "00u–06u: Huidige situatie",
  field_of_tension: "06u–08u: Spanningsveld",
  market_research: "08u–11u: Marktonderzoek",
  hesitation: "11u–12u: Twijfel",
  decision: "12u: Beslissing"
};
```

---

## Issue 2: Customer Dynamics altijd 50%

**Probleem:** Rapport, Value Tension, Commit Readiness zijn allemaal 50%.

**Oorzaak:** Dit zijn default waarden. Dynamics worden pas berekend in ROLEPLAY mode.

**Wanneer dynamics veranderen:**
| Event | Effect |
|-------|--------|
| Roleplay start | Initiële waarden op basis van persona |
| Verkoper response geëvalueerd | Dynamics updaten |
| Techniek gedetecteerd | Bonus/malus op dynamics |
| Lock questioning succesvol | Commit readiness stijgt |

**Fix opties:**

1. **Verberg dynamics in CONTEXT_GATHERING:**
```typescript
{session.mode === 'ROLEPLAY' && (
  <CustomerDynamicsPanel dynamics={debug.dynamics} />
)}
```

2. **Of toon "N/A" in plaats van 50%:**
```typescript
const rapport = session.mode === 'ROLEPLAY' 
  ? `${(dynamics.rapport * 100).toFixed(0)}%`
  : 'N/A';
```

---

## Issue 3: Fase mismatch (toont "1" terwijl title zegt "Explore")

**Probleem:** Scherm title zegt "V2 Roleplay - Explore" maar Context toont "Fase: 1".

**EPIC Fases:**
| Fase | Naam | Technieken |
|------|------|------------|
| 1 | Epic Opening | 1.x technieken |
| 2 | Probing/Explore | 2.x technieken |
| 3 | Impact/Recommend | 3.x technieken |
| 4 | Close/Decide | 4.x technieken |

**Oorzaak:** 
- De title komt uit de geselecteerde techniek ("Explore" = 2.x)
- De fase komt uit de sessie state (nog op 1)

**Fix:** Sync de fase met de geselecteerde techniek:
```typescript
// Bij techniek selectie
const epicPhase = parseInt(technique.nummer.split('.')[0]);
session.fase = epicPhase;
```

Of toon de techniek-fase in plaats van sessie-fase:
```typescript
<span>Fase: {technique.fase || session.fase}</span>
```

---

## Issue 4: Mode mismatch (CONTEXT_GATHERING vs ROLEPLAY)

**Probleem:** Het scherm zegt "Roleplay" maar de sessie is in CONTEXT_GATHERING.

**Verwachte flow:**
```
1. User selecteert techniek
2. Sessie start in CONTEXT_GATHERING
3. Hugo vraagt: sector, product, klanttype
4. Na 2-3 slots → transitie naar COACH_CHAT of ROLEPLAY
5. Roleplay begint pas na context compleet
```

**Fix:** 
1. Toon correcte mode in UI:
```typescript
<Badge>{session.mode === 'CONTEXT_GATHERING' ? 'Context' : 'Roleplay'}</Badge>
```

2. Of start direct in ROLEPLAY met defaults als user dat wil:
```typescript
// Skip context gathering button
<Button onClick={() => skipToRoleplay()}>Direct naar Roleplay</Button>
```

---

## Issue 5: Debug panel data mapping

**Probleem:** Debug panel toont mogelijk verkeerde of incomplete data.

**Verwachte debug structuur van backend:**
```typescript
interface DebugInfo {
  phase: string;                    // "CONTEXT_GATHERING" | "COACH_CHAT" | "ROLEPLAY"
  contextComplete: boolean;
  gatheredFields: string[];         // ["sector", "product"]
  
  persona?: {
    behavior_style: string;         // "analyserend" | "promoverend" | etc
    buying_clock_stage: string;     // "market_research" | etc
    difficulty_level: string;       // "bewuste_kunde" | etc
    experience_level: string;       // "enige_ervaring" | etc
  };
  
  dynamics?: {
    rapport: number;                // 0.0 - 1.0
    valueTension: number;           // 0.0 - 1.0
    commitReadiness: number;        // 0.0 - 1.0
  };
  
  evaluation?: {
    quality: string;                // "perfect" | "goed" | "bijna" | "gemist"
    detectedTechniques: Array<{
      id: string;
      naam: string;
      score: number;
    }>;
  };
  
  validatorInfo?: {
    mode: string;
    wasRepaired: boolean;
    repairAttempts: number;
  };
}
```

**Fix:** Map de backend response correct:
```typescript
const mapDebugInfo = (raw: any) => ({
  phase: raw.phase || 'UNKNOWN',
  persona: {
    behavior_style: raw.persona?.behavior_style || 'N/A',
    buying_clock_stage: buyingClockToDisplay[raw.persona?.buying_clock_stage] || raw.persona?.buying_clock_stage || 'N/A',
    difficulty_level: raw.persona?.difficulty_level || 'N/A'
  },
  dynamics: raw.mode === 'ROLEPLAY' ? {
    rapport: raw.dynamics?.rapport ?? 0.5,
    valueTension: raw.dynamics?.valueTension ?? 0.5,
    commitReadiness: raw.dynamics?.commitReadiness ?? 0.5
  } : null
});
```

---

## Issue 6: Gedragsstijl tonen als "Analytisch"

**Probleem:** Toont "Analytisch" in plaats van "Analyserend".

**Backend stuurt:** `"behavior_style": "analyserend"`

**Fix:** Gebruik correcte Nederlandse termen of map:
```typescript
const behaviorStyleToDisplay: Record<string, string> = {
  analyserend: "Analyserend",
  promoverend: "Promoverend", 
  faciliterend: "Faciliterend",
  controlerend: "Controlerend"
};
```

---

## Samenvatting: Alle fixes

| # | Issue | Fix |
|---|-------|-----|
| 1 | "Kleur groen" | Correcte buyingClockToDisplay mapping |
| 2 | 50% dynamics | Verberg in CONTEXT_GATHERING of toon N/A |
| 3 | Fase mismatch | Sync met techniek.fase |
| 4 | Mode mismatch | Toon correcte session.mode |
| 5 | Debug mapping | Map backend response correct |
| 6 | "Analytisch" | Correcte behaviorStyleToDisplay mapping |

---

## Test na fixes

```bash
# Start sessie
curl -X POST http://localhost:3001/api/v2/sessions \
  -H "Content-Type: application/json" \
  -d '{"mode": "ROLEPLAY", "techniqueId": "2.1"}'

# Check debug info
curl -X POST http://localhost:3001/api/v2/message \
  -H "Content-Type: application/json" \
  -d '{"sessionId": "xxx", "content": "Hallo, ik ben de verkoper", "isExpert": true}'
```

Verwacht:
- `phase: "ROLEPLAY"`
- `persona.behavior_style: "analyserend"` (of andere)
- `dynamics.rapport: 0.45` (berekende waarde, niet 0.5)
