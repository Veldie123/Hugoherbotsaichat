// ARCHIVED: Original V1 module moved to server/_archive/commitment-detector.ts
// These are stub exports to prevent import errors - V2 engine replaces this functionality

export function validateCommitmentDetection(...args: any[]) { throw new Error("V1 commitment-detector archived - use V2 engine"); }
