# UI → Backend Mapping (Exacte Specificatie)

Gebaseerd op de frontend screenshots - elk UI element met zijn backend call.

---

## PAGINA 1: ADMIN DASHBOARD

```
┌────────────────────────────────────────────────────────────────┐
│  HUGO HERBOTS [ADMIN]    [Search...]    🔔    [Hugo Herbots]   │
├────────────────────────────────────────────────────────────────┤
│  Hugo a.i.     [Export Data] [Config Review] [Chat Expert Mode]│
│                                                                 │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐           │
│  │ +15%     │ │ +8%      │ │ +2.3%    │ │ -5%      │           │
│  │ Total    │ │ Excellent│ │ Gem.     │ │ Needs    │           │
│  │ Sessies  │ │ Quality  │ │ Score    │ │ Improv.  │           │
│  │    6     │ │    3     │ │   80%    │ │    1     │           │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘           │
│                                                                 │
│  [Zoek...] [Alle Types ▼] [Alle Kwaliteit ▼] [≡] [⊞]           │
│                                                                 │
│  # | Techniek          | Gebruiker      | Type    | Score | ⋮  │
│  ─────────────────────────────────────────────────────────────  │
│  ☐ 2.1.1 Feitgerichte  | Jan de Vries   | Audio  | 88%   | ⋮  │
│  ☐ 4.2.4 Bezwaren      | Sarah van Dijk | Video  | 76%   | ⋮  │
│  ☐ 1.2   Gentleman's   | Mark Peters    | Chat   | 68%   | ⋮  │
│                                                                 │
│  [👁 User View]                                                 │
└────────────────────────────────────────────────────────────────┘
```

### UI ELEMENTEN → BACKEND CALLS

| UI Element | Actie | Backend Call | Response |
|------------|-------|--------------|----------|
| **KPI: Total Sessies** | Display | `GET /api/sessions/stats` | `{ total: 6 }` |
| **KPI: Excellent Quality** | Display | `GET /api/sessions/stats` | `{ excellentQuality: 3 }` |
| **KPI: Gem. Score** | Display | `GET /api/sessions/stats` | `{ averageScore: 80 }` |
| **KPI: Needs Improvement** | Display | `GET /api/sessions/stats` | `{ needsImprovement: 1 }` |
| **[Export Data]** | Click | `GET /api/sessions/export?format=csv` | CSV download |
| **[Config Review]** | Click | Navigate to `/config-review` | - |
| **[Chat Expert Mode]** | Click | Navigate to `/chat-expert` | - |
| **[Search bar]** | Type | `GET /api/sessions?search=query` | Filtered sessions |
| **[Alle Types ▼]** | Select | `GET /api/sessions?type=audio` | Filtered by type |
| **[Alle Kwaliteit ▼]** | Select | `GET /api/sessions?quality=excellent` | Filtered by quality |
| **Sessie tabel** | Load | `GET /api/sessions?limit=20&offset=0` | Session array |
| **⋮ menu** | Click | Show dropdown | - |
| **[👁 User View]** | Toggle | Set `isAdmin=false` in state | Hide debug elements |

### ⋮ MENU OPTIES

| Menu Item | Actie | Backend Call |
|-----------|-------|--------------|
| **Bekijk Details** | Click | Open modal, data already loaded |
| **Download** | Click | `GET /api/sessions/:id/export` |
| **Flag for Review** | Click | `POST /api/v2/corrections` |
| **Verwijder** | Click | `DELETE /api/sessions/:id` |

---

## PAGINA 2: SESSIE DETAIL MODAL

```
┌─────────────────────────────────────────────────────────────┐
│  Jan de Vries   [2.1.1 - Feitgerichte vragen] [✓ Excellent] │
│  Jan de Vries • TechCorp BV • AI Audio • 2025-01-15 14:23   │
├─────────────────────────────────────────────────────────────┤
│  Transcript                                                  │
│  ┌─────────────────────────────────────────────────────────┐│
│  │ [00:00] AI Coach:                                       ││
│  │ Goedemiddag! Vandaag gaan we oefenen met                ││
│  │ feitgerichte vragen. Ben je er klaar voor?              ││
│  │ > Debug Info                                             ││
│  │   ┌───────────────────────────────────────┐             ││
│  │   │ Signaal: [positief]                   │             ││
│  │   └───────────────────────────────────────┘             ││
│  │                                                          ││
│  │ [00:05] Jan:                                            ││
│  │ Ja, ik ben er klaar voor. Ik wil graag beter            ││
│  │ worden in het stellen van de juiste vragen.             ││
│  │ > Debug Info                                             ││
│  └─────────────────────────────────────────────────────────┘│
│                                                              │
│  AI Feedback                                                 │
│  ────────────────────────────────────────                    │
│  Score: 88% | Sterke punten: ...                            │
└─────────────────────────────────────────────────────────────┘
```

### UI ELEMENTEN → DATA SOURCES

| UI Element | Data Source | Locatie in Response |
|------------|-------------|---------------------|
| **Naam "Jan de Vries"** | Session | `session.userName` |
| **Badge "2.1.1"** | Session | `session.techniqueId` |
| **Badge "Excellent"** | Evaluation | `session.evaluation.quality` |
| **Timestamp [00:00]** | Message | `message.timestamp` |
| **Speaker "AI Coach"** | Message | `message.role === "assistant"` |
| **Message text** | Message | `message.content` |
| **"> Debug Info" toggle** | Click | Toggle visibility |
| **Signaal badge** | Debug | `message.debug.signal` |
| **AI Feedback sectie** | Evaluation | `session.evaluation` |

### DEBUG INFO (Expanded)

Wanneer "> Debug Info" wordt geopend:

```typescript
// Komt uit message.debug object
{
  signal: "positief" | "neutraal" | "negatief",
  // Meer velden in admin view...
}
```

---

## PAGINA 3: CONFIG REVIEW

```
┌────────────────────────────────────────────────────────────────┐
│  Config Review                                                  │
│  Review en goedkeur AI configuratie conflicten                 │
│                                                                 │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐           │
│  │ ⏱        │ │ ✓        │ │ ✗        │ │ ⊞        │           │
│  │ Pending  │ │ Approved │ │ Rejected │ │ Totaal   │           │
│  │    3     │ │    1     │ │    1     │ │    5     │           │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘           │
│                                                                 │
│  [Search] [Alle Severity ▼] [Alle Status ▼]                    │
│                                                                 │
│  Techniek | Type           | Severity | Beschrijving | ✓ | ✗   │
│  ──────────────────────────────────────────────────────────────│
│  2.1 Feitgerichte | Missing Detector | HIGH | No detector... |✓|✗│
│  3.2 Oplossing    | Pattern Mismatch | MED  | Current patt...|✓|✗│
│  4.1 Proefafsluit | Phase Error      | HIGH | AI attempted...|✓|✗│
└────────────────────────────────────────────────────────────────┘
```

### UI ELEMENTEN → BACKEND CALLS

| UI Element | Actie | Backend Call | Response |
|------------|-------|--------------|----------|
| **KPI: Pending** | Display | `GET /api/v2/config-conflicts` | `{ stats: { pending: 3 } }` |
| **KPI: Approved** | Display | `GET /api/v2/config-conflicts` | `{ stats: { approved: 1 } }` |
| **KPI: Rejected** | Display | `GET /api/v2/config-conflicts` | `{ stats: { rejected: 1 } }` |
| **KPI: Totaal** | Display | `GET /api/v2/config-conflicts` | `{ stats: { total: 5 } }` |
| **[Alle Severity ▼]** | Filter | `GET /api/v2/config-conflicts?severity=high` | Filtered |
| **[Alle Status ▼]** | Filter | `GET /api/v2/config-conflicts?status=pending` | Filtered |
| **Conflict tabel** | Load | `GET /api/v2/config-conflicts` | Array of conflicts |
| **✓ button** | Click | `POST /api/v2/config-conflicts/:id/resolve` | `{ status: "approved" }` |
| **✗ button** | Click | `POST /api/v2/config-conflicts/:id/reject` | `{ status: "rejected" }` |

### CONFLICT OBJECT STRUCTUUR

```typescript
interface ConfigConflict {
  id: string;
  techniqueId: string;           // "2.1"
  techniqueName: string;         // "Feitgerichte vragen"
  conflictType: "missing_detector" | "pattern_mismatch" | "phase_error";
  severity: "high" | "medium" | "low";
  description: string;
  status: "pending" | "approved" | "rejected";
  createdAt: string;
  sessionContext?: {
    customerMessage: string;
    expertComment: string;
  };
}
```

---

## PAGINA 4: CHAT EXPERT MODE

```
┌──────────────────────────────────────────────────────────────────────┐
│  HH  [Search...]                               🔔  [Hugo Herbots]    │
├─────────────────────────┬────────────────────────────────────────────┤
│  Chat Expert Mode       │  V2 Roleplay - Explore                     │
│  Training AI Model      │  Training AI Model                         │
│                         │                                             │
│  Epic Sales Flow        │  [Start Opname] [Stop Rollenspel] [Opnieuw]│
│  7/25 onderwerpen • 28% │                                             │
│  ┌─────────────────────┐│  Niveau: [Beginner] [Gemiddeld] [Expert]   │
│  │-1  1   2   3   4    ││                                             │
│  │Voorb Op Ontd Voo Afs││  ┌──────────────────────────────────────┐  │
│  └─────────────────────┘│  │ [Chat content area]                  │  │
│                         │  │                                       │  │
│  ▼ Fases & bijhorende   │  │ 21:41:30                    [⊕ Debug]│  │
│    technieken  [5 fases]│  │ ┌────────────────────────────────┐   │  │
│                         │  │ │ Klant Signaal: [neutraal]      │   │  │
│  ▼ Openingsfase   [2/4] │  │ │ > Persona                      │   │  │
│    1.1 Koopklimaat 💬 ⓘ │  │ │ > Context                      │   │  │
│    1.2 Gentleman's 💬 ⓘ │  │ │ > Customer Dynamics            │   │  │
│    1.3 Firmavoors. 💬 ⓘ │  │ │                                │   │  │
│    1.4 Instapvraag 💬 ⓘ │  │ │ AI Beslissingen               │   │  │
│                         │  │ │ EPIC Fase: Fase 1              │   │  │
│  > Ontdekkingsfase[0/10]│  │ │ Evaluatie: [neutraal]          │   │  │
│  > Aanbevelingsf. [0/5] │  │ └────────────────────────────────┘   │  │
│  > Beslissingsfase[0/6] │  └──────────────────────────────────────┘  │
│                         │                                             │
│  [👁]                    │  [Geselecteerd: Koopklimaat]    [Wijzig]   │
│                         │  [Type je antwoord als verkoper...] 🎤      │
└─────────────────────────┴────────────────────────────────────────────┘
```

### SIDEBAR → BACKEND CALLS

| UI Element | Actie | Backend Call | Response |
|------------|-------|--------------|----------|
| **Fases accordion** | Load | `GET /api/technieken` | Array van technieken |
| **Fase header "Openingsfase"** | Display | Groepeer op `technique.fase` | - |
| **Badge [2/4]** | Display | Tel completed technieken | - |
| **Techniek rij "1.1 Koopklimaat"** | Display | `technique.nummer` + `technique.naam` | - |
| **💬 icon** | Click | Start chat voor techniek | `POST /api/v2/sessions { techniqueId: "1.1" }` |
| **ⓘ icon** | Click | Open info modal | Geen backend call, data al geladen |
| **Progress bar** | Display | Bereken uit sessie historie | - |

### HEADER BUTTONS → BACKEND CALLS

| UI Element | Actie | Backend Call |
|------------|-------|--------------|
| **[Start Opname]** | Click | `POST /api/recordings/start { sessionId }` |
| **[Stop Rollenspel]** | Click | `POST /api/v2/sessions/:id/end` |
| **[Opnieuw]** | Click | `POST /api/v2/sessions { techniqueId, reset: true }` |
| **[Beginner]** | Toggle | `PATCH /api/v2/sessions/:id { difficulty: "beginner" }` |
| **[Gemiddeld]** | Toggle | `PATCH /api/v2/sessions/:id { difficulty: "gemiddeld" }` |
| **[Expert]** | Toggle | `PATCH /api/v2/sessions/:id { difficulty: "expert" }` |
| **💬 Chat icon** | Toggle | Set modality to "chat" |
| **📞 Phone icon** | Toggle | Set modality to "audio", start LiveKit |
| **📹 Video icon** | Toggle | Set modality to "video", start HeyGen |

### DEBUG PANEL (Admin only)

| UI Element | Data Source |
|------------|-------------|
| **Klant Signaal: [neutraal]** | `response.debug.signal` |
| **> Persona** | `response.debug.persona` (expandable) |
| **> Context** | `response.debug.context` (expandable) |
| **> Customer Dynamics** | `response.debug.customerDynamics` (expandable) |
| **EPIC Fase: Fase 1** | `response.debug.aiDecisions.epicPhase` |
| **Evaluatie: [neutraal]** | `response.debug.aiDecisions.evaluation` |

### CHAT INPUT → BACKEND CALL

| UI Element | Actie | Backend Call |
|------------|-------|--------------|
| **[Type je antwoord...]** | Submit | `POST /api/v2/message { sessionId, content, isExpert: true }` |
| **🎤 Microphone** | Click | Start audio recording → LiveKit |
| **[Wijzig]** | Click | Open techniek selector modal |

---

## PAGINA 5: TECHNIEK INFO MODAL

```
┌─────────────────────────────────────────────────────┐
│  [1.1]  Fase 1                                  ✕   │
│                                                      │
│  Koopklimaat creëren                                │
│                                                      │
│  [vertrouwen] [aanvang] [klantgericht]              │
│                                                      │
│  ┌────────────────────────────────────────────────┐ │
│  │ ⊙ Doel                                         │ │
│  │ Vertrouwen en sympathie opbouwen zodat de      │ │
│  │ klant openstaat voor het gesprek.              │ │
│  └────────────────────────────────────────────────┘ │
│                                                      │
│  Wat                                                 │
│  Gedrag, onderwerpkeuze en presentatie aanpassen    │
│  aan interesses en sfeer van klant.                 │
│                                                      │
│  Waarom                                              │
│  Om vertrouwen en comfort te creëren zodat de       │
│  klant je de verkoop gunt ('gun-effect').           │
│                                                      │
│  Wanneer                                             │
│  Direct bij aanvang van gesprek.                    │
│                                                      │
│  Hoe                                                 │
│  Gebruik observaties (omgeving, kledingstijl) en    │
│  persoonlijke aanpassingen om aansluiting te vinden.│
│                                                      │
│           [✏️ Bewerken]        [Sluiten]             │
└─────────────────────────────────────────────────────┘
```

### DATA MAPPING (uit technieken_index.json)

| UI Element | JSON Field |
|------------|------------|
| **[1.1]** badge | `technique.nummer` |
| **"Fase 1"** | `technique.fase` |
| **"Koopklimaat creëren"** | `technique.naam` |
| **Tags [vertrouwen] etc.** | `technique.tags[]` |
| **Doel sectie** | `technique.doel` |
| **Wat** | `technique.wat` |
| **Waarom** | `technique.waarom` |
| **Wanneer** | `technique.wanneer` |
| **Hoe** | `technique.hoe` |

### BUTTONS

| UI Element | Actie | Backend Call |
|------------|-------|--------------|
| **[✏️ Bewerken]** | Click (Admin only) | Navigate to edit form |
| **[Sluiten]** | Click | Close modal |
| **✕ button** | Click | Close modal |

### BEWERKEN FLOW (Admin only)

Na klik op [Bewerken]:
```
PUT /api/technieken/:id
Content-Type: application/json

{
  "doel": "Nieuwe tekst...",
  "wat": "...",
  "waarom": "...",
  "wanneer": "...",
  "hoe": "..."
}
```

Dit wijzigt `technieken_index.json` en triggert een config conflict review.

---

## DEBUG PANEL STRUCTUUR (Volledig)

Wanneer [⊕ Debug] wordt geopend in Admin view:

```
┌────────────────────────────────────────────────────┐
│ Klant Signaal: [positief] [neutraal] [negatief]    │
│                                                     │
│ ▼ Persona                                          │
│   Naam: Jan de Vries                               │
│   Behavior Style: analytisch                       │
│   Buying Clock: oriëntatie                         │
│   Experience: ervaren                              │
│   Difficulty: gemiddeld                            │
│                                                     │
│ ▼ Context                                          │
│   Sector: IT                                       │
│   Product: CRM software                            │
│   Klant Type: B2B                                  │
│   Verkoopkanaal: inside sales                      │
│   isComplete: true                                 │
│   turnNumber: 5                                    │
│   phase: 2                                         │
│   techniqueId: 2.1.1                               │
│                                                     │
│ ▼ Customer Dynamics                                │
│   Attitude: sceptisch                              │
│   Temperature: 0.6                                 │
│                                                     │
│ AI Beslissingen                                    │
│   EPIC Fase: Fase 2                                │
│   Evaluatie: [positief]                            │
│   Detected Techniques: [2.1.1]                     │
│   Suggested Next: 2.1.2                            │
│                                                     │
│ ▼ Validator (collapsed by default)                 │
│   Label: VALID                                     │
│   Confidence: 0.92                                 │
│   Violations: []                                   │
│   Was Repaired: false                              │
└────────────────────────────────────────────────────┘
```

### RESPONSE STRUCTUUR VAN /api/v2/message

```typescript
interface MessageResponse {
  response: string;           // Hugo's tekst voor chat bubble
  phase: string;              // Huidige fase
  
  // Alleen aanwezig als isExpert=true in request
  debug?: {
    signal: "positief" | "neutraal" | "negatief";
    
    persona: {
      name: string;
      behavior_style: string;
      buying_clock_stage: string;
      experience_level: string;
      difficulty_level: string;
    };
    
    context: {
      sector: string;
      product: string;
      klant_type: string;
      verkoopkanaal: string;
      isComplete: boolean;
      turnNumber: number;
      phase: number;
      techniqueId: string;
    };
    
    customerDynamics: {
      attitude: string;
      temperature: number;
    };
    
    aiDecisions: {
      epicPhase: number;
      evaluation: string;
      detectedTechniques: string[];
      suggestedNextTechnique: string;
    };
    
    validator?: {
      label: "VALID" | "WRONG_MODE" | "TOO_DIRECTIVE" | "MIXED_SIGNALS";
      confidence: number;
      violations: string[];
      wasRepaired: boolean;
      repairAttempts: number;
    };
  };
}
```

---

## ADMIN VS USER VIEW

| Feature | Admin (`isExpert=true`) | User (`isExpert=false`) |
|---------|------------------------|-------------------------|
| Debug panel | ✅ Visible | ❌ Hidden |
| [Start Opname] button | ✅ | ❌ |
| [Config Review] button | ✅ | ❌ |
| [Bewerken] in techniek modal | ✅ | ❌ |
| Flag for Review in ⋮ menu | ✅ | ❌ |
| Validator info | ✅ | ❌ |
| Sessie history | Alle sessies | Alleen eigen sessies |

Toggle via [👁 User View] button links onder.

---

*Gegenereerd voor frontend-backend mapping Hugo Platform*
