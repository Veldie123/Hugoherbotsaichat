// ARCHIVED: Original V1 module moved to server/_archive/prompt-factory.ts
// This large 54KB file contained V1 prompt generation logic
// V2 engine uses config/prompts/*.json instead

export function buildPrompt(...args: any[]) { throw new Error("V1 prompt-factory archived - use V2 config-driven prompts"); }
