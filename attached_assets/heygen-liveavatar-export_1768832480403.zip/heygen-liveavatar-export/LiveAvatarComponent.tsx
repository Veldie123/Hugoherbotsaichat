/**
 * LiveAvatar React Component
 * 
 * Volledige frontend implementatie voor HeyGen LiveAvatar SDK.
 * GEEN iframe - dit gebruikt de officiële SDK.
 * 
 * Vereist:
 * - npm install @heygen/liveavatar-web-sdk
 * - Backend endpoint /api/liveavatar/session (zie liveavatar-backend.ts)
 */

import { useState, useEffect, useCallback, useRef } from "react";
import { 
  LiveAvatarSession, 
  SessionState, 
  SessionEvent,
  VoiceChatState,
  VoiceChatEvent
} from "@heygen/liveavatar-web-sdk";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Video, VideoOff, Mic, MicOff, Phone, PhoneOff } from "lucide-react";

interface LiveAvatarProps {
  /** V2 Session ID voor koppeling met coaching engine */
  v2SessionId?: string;
  /** Callback wanneer avatar iets zegt */
  onAvatarSpeech?: (text: string) => void;
  /** Callback wanneer user iets zegt */
  onUserSpeech?: (text: string) => void;
  /** Taal voor de avatar (default: nl) */
  language?: string;
}

type ConnectionStatus = "idle" | "connecting" | "connected" | "error" | "disconnected";

export function LiveAvatarComponent({ 
  v2SessionId,
  onAvatarSpeech,
  onUserSpeech,
  language = "nl"
}: LiveAvatarProps) {
  // Session state
  const [status, setStatus] = useState<ConnectionStatus>("idle");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isAvatarTalking, setIsAvatarTalking] = useState(false);
  const [isUserTalking, setIsUserTalking] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  
  // Transcript
  const [transcript, setTranscript] = useState<Array<{
    role: "avatar" | "user";
    text: string;
    timestamp: Date;
  }>>([]);
  
  // Session ref
  const sessionRef = useRef<LiveAvatarSession | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  
  /**
   * Start LiveAvatar sessie
   */
  const startSession = useCallback(async () => {
    try {
      setStatus("connecting");
      setErrorMessage(null);
      
      // 1. Haal session token op van backend
      const response = await fetch("/api/liveavatar/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ language })
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.details || error.error || "Failed to create session");
      }
      
      const { session_id, session_token } = await response.json();
      console.log("[LiveAvatar] Got session:", session_id);
      
      // 2. Maak LiveAvatar sessie met SDK
      const session = new LiveAvatarSession(session_id, session_token, {
        voiceChat: true  // Enable voice interaction
      });
      
      sessionRef.current = session;
      
      // 3. Setup event listeners
      setupEventListeners(session);
      
      // 4. Start de sessie
      await session.start();
      
      console.log("[LiveAvatar] Session started");
      setStatus("connected");
      
    } catch (error: any) {
      console.error("[LiveAvatar] Start error:", error);
      setStatus("error");
      setErrorMessage(error.message);
    }
  }, [language]);
  
  /**
   * Stop LiveAvatar sessie
   */
  const stopSession = useCallback(async () => {
    try {
      if (sessionRef.current) {
        await sessionRef.current.stop();
        sessionRef.current = null;
      }
      setStatus("disconnected");
      setIsAvatarTalking(false);
      setIsUserTalking(false);
    } catch (error: any) {
      console.error("[LiveAvatar] Stop error:", error);
    }
  }, []);
  
  /**
   * Setup event listeners voor de sessie
   */
  const setupEventListeners = useCallback((session: LiveAvatarSession) => {
    // Session events
    session.on(SessionEvent.SESSION_STARTED, () => {
      console.log("[LiveAvatar] Event: session_started");
      setStatus("connected");
    });
    
    session.on(SessionEvent.SESSION_STOPPED, () => {
      console.log("[LiveAvatar] Event: session_stopped");
      setStatus("disconnected");
    });
    
    // Agent (avatar) events
    session.on(SessionEvent.AGENT_TALKING, (data: any) => {
      console.log("[LiveAvatar] Avatar talking:", data);
      setIsAvatarTalking(true);
      
      if (data?.text) {
        setTranscript(prev => [...prev, {
          role: "avatar",
          text: data.text,
          timestamp: new Date()
        }]);
        onAvatarSpeech?.(data.text);
      }
    });
    
    session.on(SessionEvent.AGENT_STOPPED_TALKING, () => {
      console.log("[LiveAvatar] Avatar stopped talking");
      setIsAvatarTalking(false);
    });
    
    // User speech events
    session.on(VoiceChatEvent.USER_SPEECH, (data: any) => {
      console.log("[LiveAvatar] User speech:", data);
      setIsUserTalking(true);
      
      if (data?.text) {
        setTranscript(prev => [...prev, {
          role: "user",
          text: data.text,
          timestamp: new Date()
        }]);
        onUserSpeech?.(data.text);
      }
    });
    
    session.on(VoiceChatEvent.USER_SPEECH_END, () => {
      console.log("[LiveAvatar] User stopped talking");
      setIsUserTalking(false);
    });
    
    // Error handling
    session.on("error", (error: any) => {
      console.error("[LiveAvatar] Error event:", error);
      setErrorMessage(error?.message || "Unknown error");
    });
    
    // Video stream - attach to video element
    session.on("stream", (stream: MediaStream) => {
      console.log("[LiveAvatar] Got video stream");
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    });
    
  }, [onAvatarSpeech, onUserSpeech]);
  
  /**
   * Laat avatar specifieke tekst spreken
   */
  const speakText = useCallback(async (text: string) => {
    if (sessionRef.current && status === "connected") {
      try {
        await sessionRef.current.speak(text);
      } catch (error: any) {
        console.error("[LiveAvatar] Speak error:", error);
      }
    }
  }, [status]);
  
  /**
   * Onderbreek huidige avatar speech
   */
  const interrupt = useCallback(async () => {
    if (sessionRef.current && isAvatarTalking) {
      try {
        await sessionRef.current.interrupt();
      } catch (error: any) {
        console.error("[LiveAvatar] Interrupt error:", error);
      }
    }
  }, [isAvatarTalking]);
  
  /**
   * Toggle mute
   */
  const toggleMute = useCallback(() => {
    // Note: Mute implementation depends on SDK capabilities
    setIsMuted(prev => !prev);
  }, []);
  
  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (sessionRef.current) {
        sessionRef.current.stop().catch(console.error);
      }
    };
  }, []);
  
  // Status badge color
  const getStatusColor = () => {
    switch (status) {
      case "connected": return "bg-green-500";
      case "connecting": return "bg-yellow-500";
      case "error": return "bg-red-500";
      default: return "bg-gray-500";
    }
  };
  
  return (
    <Card className="w-full max-w-2xl">
      <CardHeader className="flex flex-row items-center justify-between gap-2">
        <CardTitle className="flex items-center gap-2">
          <Video className="h-5 w-5" />
          LiveAvatar Video
        </CardTitle>
        <Badge className={getStatusColor()}>
          {status === "connecting" && <Loader2 className="h-3 w-3 mr-1 animate-spin" />}
          {status}
        </Badge>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Video Container */}
        <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
          {status === "connected" ? (
            <video
              ref={videoRef}
              autoPlay
              playsInline
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="absolute inset-0 flex items-center justify-center">
              {status === "connecting" ? (
                <Loader2 className="h-12 w-12 animate-spin text-white" />
              ) : (
                <VideoOff className="h-12 w-12 text-gray-500" />
              )}
            </div>
          )}
          
          {/* Speaking indicators */}
          {status === "connected" && (
            <div className="absolute bottom-4 left-4 flex gap-2">
              {isAvatarTalking && (
                <Badge className="bg-blue-500 animate-pulse">
                  Avatar speaking...
                </Badge>
              )}
              {isUserTalking && (
                <Badge className="bg-green-500 animate-pulse">
                  You're speaking...
                </Badge>
              )}
            </div>
          )}
        </div>
        
        {/* Error message */}
        {errorMessage && (
          <div className="p-3 bg-red-100 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-lg text-sm">
            {errorMessage}
          </div>
        )}
        
        {/* Controls */}
        <div className="flex justify-center gap-3">
          {status === "idle" || status === "disconnected" || status === "error" ? (
            <Button 
              onClick={startSession}
              className="gap-2"
              data-testid="button-start-liveavatar"
            >
              <Phone className="h-4 w-4" />
              Start Video Call
            </Button>
          ) : status === "connecting" ? (
            <Button disabled className="gap-2">
              <Loader2 className="h-4 w-4 animate-spin" />
              Connecting...
            </Button>
          ) : (
            <>
              <Button
                variant="outline"
                onClick={toggleMute}
                className="gap-2"
                data-testid="button-toggle-mute"
              >
                {isMuted ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                {isMuted ? "Unmute" : "Mute"}
              </Button>
              
              {isAvatarTalking && (
                <Button
                  variant="outline"
                  onClick={interrupt}
                  data-testid="button-interrupt"
                >
                  Interrupt
                </Button>
              )}
              
              <Button
                variant="destructive"
                onClick={stopSession}
                className="gap-2"
                data-testid="button-stop-liveavatar"
              >
                <PhoneOff className="h-4 w-4" />
                End Call
              </Button>
            </>
          )}
        </div>
        
        {/* Transcript */}
        {transcript.length > 0 && (
          <div className="mt-4 max-h-48 overflow-y-auto space-y-2 p-3 bg-muted rounded-lg">
            <h4 className="text-sm font-medium mb-2">Transcript</h4>
            {transcript.map((entry, i) => (
              <div 
                key={i}
                className={`text-sm p-2 rounded ${
                  entry.role === "avatar" 
                    ? "bg-blue-100 dark:bg-blue-900/30" 
                    : "bg-green-100 dark:bg-green-900/30"
                }`}
              >
                <span className="font-medium">
                  {entry.role === "avatar" ? "Hugo" : "Jij"}:
                </span>{" "}
                {entry.text}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default LiveAvatarComponent;
