/**
 * TypeScript Types voor LiveAvatar integratie
 * 
 * Deze types zijn gebaseerd op de @heygen/liveavatar-web-sdk package.
 * Sommige types worden direct uit de SDK geëxporteerd.
 */

// Re-export van SDK types
export { 
  SessionState,
  SessionEvent,
  Language,
  SessionDisconnectReason,
  ConnectionQuality,
  VoiceChatState,
  VoiceChatEvent
} from "@heygen/liveavatar-web-sdk";

/**
 * Configuration voor LiveAvatarSession
 */
export interface LiveAvatarSessionConfig {
  /** Enable voice chat (microphone input) */
  voiceChat?: boolean;
}

/**
 * Response van /api/liveavatar/session endpoint
 */
export interface LiveAvatarTokenResponse {
  session_id: string;
  session_token: string;
}

/**
 * Request body voor /api/liveavatar/session endpoint
 */
export interface LiveAvatarTokenRequest {
  /** Voice ID voor de avatar (optioneel) */
  voiceId?: string;
  /** Context ID voor persona (optioneel) */
  contextId?: string;
  /** Taal: nl, en, de, fr, etc. (default: nl) */
  language?: string;
}

/**
 * LiveAvatar API Error Response
 */
export interface LiveAvatarApiError {
  code: number;
  message: string;
  data?: Array<{
    loc: string[];
    message: string;
    params?: Record<string, any>;
  }>;
}

/**
 * Transcript entry voor UI
 */
export interface TranscriptEntry {
  role: "avatar" | "user";
  text: string;
  timestamp: Date;
}

/**
 * Connection status voor UI state management
 */
export type LiveAvatarConnectionStatus = 
  | "idle" 
  | "connecting" 
  | "connected" 
  | "error" 
  | "disconnected";

/**
 * Props voor LiveAvatarComponent
 */
export interface LiveAvatarComponentProps {
  /** V2 Session ID voor koppeling met coaching engine */
  v2SessionId?: string;
  /** Callback wanneer avatar iets zegt */
  onAvatarSpeech?: (text: string) => void;
  /** Callback wanneer user iets zegt */
  onUserSpeech?: (text: string) => void;
  /** Taal voor de avatar (default: nl) */
  language?: string;
  /** Custom CSS class */
  className?: string;
}

/**
 * Hook return type voor useLiveAvatar
 */
export interface UseLiveAvatarReturn {
  /** Current connection status */
  status: LiveAvatarConnectionStatus;
  /** Error message if any */
  error: string | null;
  /** Whether avatar is currently talking */
  isAvatarTalking: boolean;
  /** Whether user is currently talking */
  isUserTalking: boolean;
  /** Conversation transcript */
  transcript: TranscriptEntry[];
  /** Start the LiveAvatar session */
  start: () => Promise<void>;
  /** Stop the LiveAvatar session */
  stop: () => Promise<void>;
  /** Make avatar speak specific text */
  speak: (text: string) => Promise<void>;
  /** Interrupt avatar speech */
  interrupt: () => Promise<void>;
}
