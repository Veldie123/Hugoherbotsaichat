/**
 * LiveAvatar Backend Endpoint
 * 
 * Kopieer deze code naar server/routes.ts
 * 
 * Vereiste environment variables:
 * - HEYGEN_API_KEY: Je HeyGen API key
 * - Live_avatar_ID_heygen_hugoherbots: De avatar_id van je LiveAvatar
 */

import { Express, Request, Response } from "express";

export function registerLiveAvatarRoutes(app: Express) {
  
  // POST /api/liveavatar/session - Create LiveAvatar session with token
  app.post("/api/liveavatar/session", async (req: Request, res: Response) => {
    try {
      const { voiceId, contextId, language = "nl" } = req.body;
      
      // Validate required environment variables
      const heygenApiKey = process.env.HEYGEN_API_KEY;
      const avatarId = process.env.Live_avatar_ID_heygen_hugoherbots;
      
      if (!heygenApiKey) {
        console.error("[LiveAvatar] HEYGEN_API_KEY is missing");
        return res.status(500).json({ 
          error: "HeyGen API key not configured",
          details: "HEYGEN_API_KEY environment variable is not set"
        });
      }
      
      if (!avatarId) {
        console.error("[LiveAvatar] Live_avatar_ID_heygen_hugoherbots is missing");
        return res.status(500).json({ 
          error: "LiveAvatar avatar ID not configured",
          details: "Live_avatar_ID_heygen_hugoherbots environment variable is not set"
        });
      }
      
      console.log("[LiveAvatar] Creating session with avatar:", avatarId);
      
      // Use LiveAvatar API to create a session token
      // FULL mode is required when using avatar_persona
      const requestBody = {
        mode: "FULL",
        avatar_id: avatarId,
        avatar_persona: {
          voice_id: voiceId || undefined,
          context_id: contextId || undefined,
          language: language
        }
      };
      
      console.log("[LiveAvatar] Token request body:", JSON.stringify(requestBody, null, 2));
      
      const response = await fetch("https://api.liveavatar.com/v1/sessions/token", {
        method: "POST",
        headers: {
          "X-API-KEY": heygenApiKey,
          "Accept": "application/json",
          "Content-Type": "application/json"
        },
        body: JSON.stringify(requestBody)
      });
      
      if (!response.ok) {
        const errorBody = await response.text();
        console.error(`[LiveAvatar] Token request failed - Status: ${response.status}, Body: ${errorBody}`);
        return res.status(response.status).json({ 
          error: "Failed to create LiveAvatar session", 
          details: errorBody,
          status: response.status
        });
      }
      
      const responseData = await response.json();
      console.log("[LiveAvatar] Token response code:", responseData.code);
      
      // LiveAvatar returns { code: 1000, data: { session_id, session_token } }
      const sessionData = responseData.data || responseData;
      
      if (!sessionData.session_id || !sessionData.session_token) {
        console.error("[LiveAvatar] Invalid response - missing session_id or session_token");
        return res.status(500).json({ 
          error: "Invalid response from LiveAvatar", 
          details: "Missing session_id or session_token in response"
        });
      }
      
      console.log("[LiveAvatar] Session created:", sessionData.session_id);
      
      // Validate that session_token is a JWT
      const token = sessionData.session_token;
      const dotCount = (token.match(/\./g) || []).length;
      const isJwt = dotCount === 2;
      
      if (!isJwt) {
        console.warn("[LiveAvatar] WARNING: session_token is not a JWT!");
      }
      
      // Return session credentials
      // The client SDK will handle starting the LiveKit connection
      res.json({
        session_id: sessionData.session_id,
        session_token: sessionData.session_token
      });
      
    } catch (error: any) {
      console.error("[LiveAvatar] Unexpected error:", error.message, error.stack);
      res.status(500).json({ error: error.message });
    }
  });
  
  // GET /api/liveavatar/status - Check if LiveAvatar is configured
  app.get("/api/liveavatar/status", async (req: Request, res: Response) => {
    const heygenApiKey = process.env.HEYGEN_API_KEY;
    const avatarId = process.env.Live_avatar_ID_heygen_hugoherbots;
    
    res.json({
      configured: Boolean(heygenApiKey && avatarId),
      hasApiKey: Boolean(heygenApiKey),
      hasAvatarId: Boolean(avatarId),
      avatarIdPreview: avatarId ? `${avatarId.substring(0, 8)}...` : null
    });
  });
}
