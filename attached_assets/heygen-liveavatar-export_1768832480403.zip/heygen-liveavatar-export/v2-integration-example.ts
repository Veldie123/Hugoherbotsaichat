/**
 * Voorbeeld: LiveAvatar koppeling met Hugo V2 Coaching Engine
 * 
 * Dit toont hoe je LiveAvatar integreert met de V2 engine voor:
 * - User speech → V2 engine → Avatar response
 * - Real-time coaching feedback via video avatar
 */

import { LiveAvatarSession, SessionEvent, VoiceChatEvent } from "@heygen/liveavatar-web-sdk";

interface V2IntegrationConfig {
  /** V2 Session ID */
  sessionId: string;
  /** Huidige mode: ROLEPLAY, COACH_CHAT, CONTEXT_GATHERING, etc. */
  mode: string;
  /** Base URL voor API calls */
  apiBaseUrl?: string;
}

/**
 * Creëer een LiveAvatar sessie gekoppeld aan V2 engine
 */
export async function createIntegratedLiveAvatarSession(
  config: V2IntegrationConfig
): Promise<LiveAvatarSession> {
  const { sessionId, mode, apiBaseUrl = "" } = config;
  
  // 1. Haal LiveAvatar token op
  const tokenResponse = await fetch(`${apiBaseUrl}/api/liveavatar/session`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ language: "nl" })
  });
  
  if (!tokenResponse.ok) {
    const error = await tokenResponse.json();
    throw new Error(error.details || error.error);
  }
  
  const { session_id, session_token } = await tokenResponse.json();
  
  // 2. Maak LiveAvatar sessie
  const liveAvatarSession = new LiveAvatarSession(session_id, session_token, {
    voiceChat: true
  });
  
  // 3. Koppel user speech aan V2 engine
  liveAvatarSession.on(VoiceChatEvent.USER_SPEECH_END, async (data: any) => {
    const userText = data?.text;
    if (!userText) return;
    
    console.log("[V2 Integration] User said:", userText);
    
    try {
      // Stuur naar V2 engine
      const response = await sendToV2Engine(sessionId, userText, mode, apiBaseUrl);
      
      // Laat avatar het antwoord spreken
      if (response) {
        await liveAvatarSession.speak(response);
      }
    } catch (error) {
      console.error("[V2 Integration] Error processing speech:", error);
    }
  });
  
  return liveAvatarSession;
}

/**
 * Stuur bericht naar V2 engine en krijg response
 */
async function sendToV2Engine(
  sessionId: string,
  message: string,
  mode: string,
  apiBaseUrl: string
): Promise<string> {
  // Gebruik streaming endpoint voor real-time response
  const response = await fetch(`${apiBaseUrl}/api/session/${sessionId}/message/stream`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ 
      message,
      mode,
      modality: "video"  // Indicate we're in video mode
    })
  });
  
  if (!response.ok) {
    throw new Error(`V2 engine error: ${response.status}`);
  }
  
  // Collect streamed response
  const reader = response.body?.getReader();
  if (!reader) throw new Error("No response body");
  
  let fullResponse = "";
  const decoder = new TextDecoder();
  
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    
    const chunk = decoder.decode(value, { stream: true });
    
    // Parse SSE events
    const lines = chunk.split("\n");
    for (const line of lines) {
      if (line.startsWith("data: ")) {
        try {
          const data = JSON.parse(line.slice(6));
          if (data.content) {
            fullResponse += data.content;
          }
        } catch {
          // Skip non-JSON lines
        }
      }
    }
  }
  
  return fullResponse;
}

/**
 * Voorbeeld gebruik in React component
 */
export function exampleUsage() {
  // In je React component:
  /*
  const [liveAvatar, setLiveAvatar] = useState<LiveAvatarSession | null>(null);
  
  const startIntegratedSession = async () => {
    const session = await createIntegratedLiveAvatarSession({
      sessionId: "your-v2-session-id",
      mode: "ROLEPLAY"
    });
    
    await session.start();
    setLiveAvatar(session);
  };
  */
}

/**
 * Mode-specifieke instructies voor de avatar
 * 
 * In ROLEPLAY mode: Avatar speelt de klant
 * In COACH_CHAT mode: Avatar is Hugo de coach
 * In CONTEXT_GATHERING mode: Avatar vraagt context
 */
export function getAvatarBehaviorForMode(mode: string): string {
  switch (mode) {
    case "ROLEPLAY":
      return "Je bent nu een klant in een sales roleplay scenario.";
    case "COACH_CHAT":
      return "Je bent Hugo, een ervaren sales coach die LSD-methode gebruikt.";
    case "CONTEXT_GATHERING":
      return "Je verzamelt context voor de training sessie.";
    case "FEEDBACK":
    case "DEBRIEF":
      return "Je geeft feedback over de afgelopen roleplay.";
    default:
      return "Je bent Hugo, een behulpzame sales coach.";
  }
}
