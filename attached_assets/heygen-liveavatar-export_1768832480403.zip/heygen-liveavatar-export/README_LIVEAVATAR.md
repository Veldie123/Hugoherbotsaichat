# HeyGen LiveAvatar Integratie

## Overzicht

Deze export bevat alles wat nodig is om HeyGen LiveAvatar te integreren met de Hugo coaching platform. LiveAvatar is de **nieuwere** HeyGen API (Interactive Avatar is deprecating). We gebruiken de **SDK** (`@heygen/liveavatar-web-sdk`), GEEN iframe embed.

## Status

| Component | Status | Locatie |
|-----------|--------|---------|
| Backend endpoint | ✅ Klaar | `server/routes.ts` → `/api/liveavatar/session` |
| SDK package | ✅ Geïnstalleerd | `@heygen/liveavatar-web-sdk` v0.0.9 |
| Frontend component | ❌ Niet gebouwd | Moet gemaakt worden |
| Avatar in HeyGen | ❌ EXPIRED | Moet vernieuwd worden |

## STAP 1: Avatar Vernieuwen in HeyGen

**CRITICAL**: De huidige avatar is verlopen!

```
Error: "Avatar is expired"
avatar_id: f8343d95-8dd8-4318-aec0-597199fa99ac
```

### Actie vereist:
1. Ga naar [HeyGen Dashboard](https://app.heygen.com) → LiveAvatar sectie
2. Maak een nieuwe LiveAvatar of vernieuw de bestaande
3. Kopieer de nieuwe `avatar_id`
4. Update de Replit secret: `Live_avatar_ID_heygen_hugoherbots`

---

## STAP 2: Environment Variables

Vereiste secrets in Replit:

| Secret | Beschrijving |
|--------|--------------|
| `HEYGEN_API_KEY` | Je HeyGen API key |
| `Live_avatar_ID_heygen_hugoherbots` | De avatar_id van je LiveAvatar |

---

## STAP 3: Package Installeren

```bash
npm install @heygen/liveavatar-web-sdk
```

> **Let op**: Dit is NIET hetzelfde als `@heygen/streaming-avatar` (dat is Interactive Avatar, deprecated).

---

## STAP 4: Backend Implementatie

De backend endpoint is al gebouwd. Kopieer deze code naar `server/routes.ts`:

```typescript
// POST /api/liveavatar/session - Create LiveAvatar session with token
app.post("/api/liveavatar/session", async (req, res) => {
  try {
    const { voiceId, contextId, language = "nl" } = req.body;
    
    const heygenApiKey = process.env.HEYGEN_API_KEY;
    const avatarId = process.env.Live_avatar_ID_heygen_hugoherbots;
    
    if (!heygenApiKey) {
      return res.status(500).json({ 
        error: "HeyGen API key not configured"
      });
    }
    
    if (!avatarId) {
      return res.status(500).json({ 
        error: "LiveAvatar avatar ID not configured"
      });
    }
    
    console.log("[LiveAvatar] Creating session with avatar:", avatarId);
    
    // LiveAvatar API - FULL mode met avatar_persona
    const requestBody = {
      mode: "FULL",
      avatar_id: avatarId,
      avatar_persona: {
        voice_id: voiceId || undefined,
        context_id: contextId || undefined,
        language: language
      }
    };
    
    const response = await fetch("https://api.liveavatar.com/v1/sessions/token", {
      method: "POST",
      headers: {
        "X-API-KEY": heygenApiKey,
        "Accept": "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(requestBody)
    });
    
    if (!response.ok) {
      const errorBody = await response.text();
      console.error(`[LiveAvatar] Token request failed:`, errorBody);
      return res.status(response.status).json({ 
        error: "Failed to create LiveAvatar session", 
        details: errorBody
      });
    }
    
    const responseData = await response.json();
    const sessionData = responseData.data || responseData;
    
    if (!sessionData.session_id || !sessionData.session_token) {
      return res.status(500).json({ 
        error: "Invalid response from LiveAvatar"
      });
    }
    
    console.log("[LiveAvatar] Session created:", sessionData.session_id);
    
    res.json({
      session_id: sessionData.session_id,
      session_token: sessionData.session_token
    });
  } catch (error: any) {
    console.error("[LiveAvatar] Error:", error.message);
    res.status(500).json({ error: error.message });
  }
});
```

---

## STAP 5: Frontend Implementatie

Gebruik de `LiveAvatarSession` class uit de SDK. Zie `LiveAvatarComponent.tsx` voor een volledig voorbeeld.

### Basis flow:

```typescript
import { LiveAvatarSession } from "@heygen/liveavatar-web-sdk";

// 1. Haal session token op van backend
const response = await fetch("/api/liveavatar/session", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ language: "nl" })
});
const { session_id, session_token } = await response.json();

// 2. Maak LiveAvatar sessie
const session = new LiveAvatarSession(session_id, session_token, {
  voiceChat: true  // Enable voice interaction
});

// 3. Luister naar events
session.on("session_started", () => console.log("Avatar ready!"));
session.on("agent_talking", (text) => console.log("Avatar says:", text));
session.on("user_speech", (text) => console.log("User said:", text));

// 4. Start de sessie
await session.start();

// 5. Stop wanneer klaar
await session.stop();
```

---

## SDK API Reference

### LiveAvatarSession Constructor

```typescript
new LiveAvatarSession(sessionId: string, sessionToken: string, config: SessionConfig)
```

### SessionConfig

```typescript
interface SessionConfig {
  voiceChat?: boolean;       // Enable voice chat (default: false)
  // Meer opties in SDK docs
}
```

### Events

| Event | Beschrijving |
|-------|--------------|
| `session_started` | Sessie is gestart, avatar is ready |
| `session_stopped` | Sessie is gestopt |
| `agent_talking` | Avatar spreekt (met tekst) |
| `agent_stopped_talking` | Avatar is klaar met spreken |
| `user_speech` | User speech gedetecteerd |
| `user_speech_end` | User is klaar met spreken |
| `connection_quality` | Connection quality update |
| `error` | Error opgetreden |

### Methods

| Method | Beschrijving |
|--------|--------------|
| `start()` | Start de sessie |
| `stop()` | Stop de sessie |
| `speak(text)` | Laat avatar tekst spreken |
| `interrupt()` | Onderbreek huidige speech |

---

## Integratie met V2 Engine

Om LiveAvatar te koppelen aan de Hugo V2 coaching engine:

1. **User spreekt** → `user_speech` event → Stuur naar V2 engine
2. **V2 Engine antwoordt** → Gebruik `session.speak(response)` of laat LiveAvatar's eigen AI antwoorden
3. **Avatar spreekt** → `agent_talking` event → Toon transcript

### Voorbeeld integratie:

```typescript
// User speech naar V2 engine
session.on("user_speech", async (text) => {
  const response = await fetch(`/api/session/${sessionId}/message/stream`, {
    method: "POST",
    body: JSON.stringify({ message: text, mode: "ROLEPLAY" })
  });
  
  // Stream response naar avatar
  const reader = response.body.getReader();
  // ... handle streaming
  session.speak(fullResponse);
});
```

---

## Troubleshooting

### "Avatar is expired"
→ Avatar moet vernieuwd worden in HeyGen dashboard

### "HEYGEN_API_KEY not configured"
→ Voeg secret toe in Replit Secrets

### "LiveAvatar avatar ID not configured"
→ Voeg `Live_avatar_ID_heygen_hugoherbots` secret toe

### Frontend SDK import error
→ Zorg dat package geïnstalleerd is: `npm install @heygen/liveavatar-web-sdk`

---

## Documentatie Links

- [LiveAvatar API Docs](https://docs.liveavatar.com)
- [LiveAvatar SDK GitHub](https://github.com/heygen-com/live-avatar-js-sdk)
- [HeyGen Dashboard](https://app.heygen.com)

---

## Bestanden in deze export

| Bestand | Beschrijving |
|---------|--------------|
| `README_LIVEAVATAR.md` | Deze instructies |
| `liveavatar-backend.ts` | Backend endpoint code |
| `LiveAvatarComponent.tsx` | Frontend component voorbeeld |
| `liveavatar-types.ts` | TypeScript types |
| `package-requirements.txt` | Vereiste npm packages |
