// ARCHIVED: Original V1 module moved to server/_archive/mode-transitions.ts
// These are stub exports to prevent import errors - V2 engine replaces this functionality

export type Mode = "COACH_INTRO" | "CONTEXT_GATHERING" | "ROLEPLAY" | "COACH_FEEDBACK";
export function determineNextMode(...args: any[]): Mode { throw new Error("V1 mode-transitions archived - use V2 engine"); }
