// ARCHIVED: Original V1 module moved to server/_archive/feedback-aggregator.ts
// These are stub exports to prevent import errors - V2 engine replaces this functionality

export function aggregateFeedback(...args: any[]) { throw new Error("V1 feedback-aggregator archived - use V2 engine"); }
export function renderFeedbackTemplate(...args: any[]) { throw new Error("V1 feedback-aggregator archived - use V2 engine"); }
