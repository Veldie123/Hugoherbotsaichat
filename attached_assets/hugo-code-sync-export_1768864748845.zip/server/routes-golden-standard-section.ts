  // POST /api/v2/session/save-reference - Save user message as reference answer (for V2 sessions)
  app.post("/api/v2/session/save-reference", async (req, res) => {
    try {
      const { sessionId, techniqueId, message, context, matchStatus, signal, detectedTechnique } = req.body;
      
      if (!sessionId) {
        return res.status(400).json({ error: "sessionId is required" });
      }
      
      // Load session from database
      const dbSession = await storage.getV2Session(sessionId);
      if (!dbSession) {
        return res.status(404).json({ error: "V2 Session not found" });
      }
      const session = dbToV2State(dbSession);
      
      // Determine if this is a correction (mismatch between expert selection and AI detection)
      const isCorrection = matchStatus === 'mismatch' && detectedTechnique && detectedTechnique !== techniqueId;
      
      // Save as reference answer using the V2 reference-answers module
      const { saveReferenceAnswer } = await import('./v2/reference-answers');
      
      const referenceAnswer = saveReferenceAnswer({
        techniqueId: techniqueId || session.techniqueId,
        customerSignal: signal || 'opening',
        customerMessage: '',
        sellerResponse: message,
        context: context || session.context?.gathered || {},
        recordedBy: 'Hugo (Expert Mode)',
        detectedTechnique: isCorrection ? detectedTechnique : undefined,
        isCorrection
      });
      
      console.log(`[V2] Saved reference answer for technique ${techniqueId}${isCorrection ? ' (CORRECTION from ' + detectedTechnique + ')' : ''}`);
      
      res.json({
        success: true,
        referenceAnswer,
        isCorrection,
        message: isCorrection 
          ? `Correctie opgeslagen: AI detecteerde ${detectedTechnique}, expert zegt ${techniqueId}`
          : `Referentie opgeslagen voor techniek ${techniqueId}`
      });
    } catch (error: any) {
      console.error("[V2] Save reference error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // POST /api/v2/session/flag-customer-response - Flag a customer response as incorrect
  app.post("/api/v2/session/flag-customer-response", async (req, res) => {
    try {
      const { sessionId, turnNumber, customerMessage, customerSignal, currentPhase, techniqueId, expertComment, context } = req.body;
      
      if (!sessionId || !expertComment) {
        return res.status(400).json({ error: "sessionId and expertComment are required" });
      }
      
      // Load session from database for additional context
      const dbSession = await storage.getV2Session(sessionId);
      const session = dbSession ? dbToV2State(dbSession) : null;
      
      // Use conversationHistory from request (preferred) or build from session
      const reqConversationHistory = req.body.conversationHistory;
      const finalConversationHistory = (reqConversationHistory && reqConversationHistory.length > 0) 
        ? reqConversationHistory 
        : (session?.conversationHistory?.map((turn: any) => ({
            role: turn.role,
            content: turn.content
          })) || []);
      
      // Analyze the feedback and generate conflicts
      const { analyzeCustomerResponseFeedback } = await import('./v2/config-consistency');
      
      const conflicts = analyzeCustomerResponseFeedback({
        sessionId,
        turnNumber: turnNumber || 0,
        customerMessage: customerMessage || '',
        customerSignal: customerSignal || 'unknown',
        currentPhase: currentPhase || session?.phase || 2,
        techniqueId: techniqueId || session?.techniqueId || '2.1',
        expertComment,
        context: context || session?.context?.gathered || {},
        conversationHistory: finalConversationHistory
      });
      
      console.log(`[V2] Flagged customer response: ${customerSignal} in phase ${currentPhase}. Found ${conflicts.length} conflicts.`);
      
      res.json({
        success: true,
        conflictsFound: conflicts.length,
        conflicts: conflicts.map(c => ({
          id: c.id,
          severity: c.severity,
          description: c.description
        })),
        message: `Feedback opgeslagen. ${conflicts.length} conflict(en) gedetecteerd in /admin/conflicts.`
      });
    } catch (error: any) {
      console.error("[V2] Flag customer response error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // POST /api/v2/session/flag-evaluation - Flag an AI evaluation as incorrect
  app.post("/api/v2/session/flag-evaluation", async (req, res) => {
    try {
      const { 
        sessionId, 
        turnNumber, 
        evaluationFeedback,
        evaluationDetected,
        evaluationScore,
        expectedMoves,
        currentPhase, 
        techniqueId, 
        expertComment,
        context,
        conversationHistory: reqConversationHistory
      } = req.body;
      
      if (!sessionId || !expertComment) {
        return res.status(400).json({ error: "sessionId and expertComment are required" });
      }
      
      // Load session from database for additional context
      const dbSession = await storage.getV2Session(sessionId);
      const session = dbSession ? dbToV2State(dbSession) : null;
      
      // Use conversationHistory from request (preferred) or build from session
      const finalConversationHistory = (reqConversationHistory && reqConversationHistory.length > 0) 
        ? reqConversationHistory 
        : (session?.conversationHistory?.map((turn: any) => ({
            role: turn.role,
            content: turn.content
          })) || []);
      
      // Generate a conflict for evaluation feedback
      const { addConflict } = await import('./v2/config-consistency');
      
      const conflict = addConflict({
        correctionId: `eval-${sessionId}-${turnNumber}`,
        severity: 'medium',
        configFile: 'ssot/evaluator_overlay.json',
        techniqueId: techniqueId || '2.1',
        conflictType: 'detector_mismatch',
        description: `AI evaluation possibly incorrect. Expected: ${expectedMoves?.join(', ') || 'unknown'}. Detected: ${evaluationDetected ? 'Yes' : 'No'}. Expert comment: "${expertComment}"`,
        suggestedChange: JSON.stringify({
          file: 'ssot/evaluator_overlay.json',
          operation: 'review',
          path: `techniques.${techniqueId}`,
          suggestion: 'Review technique detection patterns based on expert feedback',
          expertComment,
          evaluationWas: evaluationFeedback,
          expectedMoves
        }),
        sessionContext: {
          sessionId,
          turnNumber: turnNumber || 0,
          customerMessage: evaluationFeedback || '',
          customerSignal: 'evaluation',
          currentPhase: currentPhase || 2,
          expertComment,
          context: context || {},
          conversationHistory: finalConversationHistory
        }
      });
      
      console.log(`[V2] Flagged AI evaluation in phase ${currentPhase}. Conflict: ${conflict.id}`);
      
      res.json({
        success: true,
        conflictsFound: 1,
        conflicts: [{
          id: conflict.id,
          severity: conflict.severity,
          description: conflict.description
        }],
        message: `Evaluatie feedback opgeslagen. Conflict aangemaakt in /admin/conflicts.`
      });
    } catch (error: any) {
      console.error("[V2] Flag evaluation error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // POST /api/v2/rag/index - Index RAG corpus (admin only)
  app.post("/api/v2/rag/index", async (req, res) => {
    try {
      const { indexCorpus, getDocumentCount } = await import('./v2/rag-service');
      
      const beforeCount = await getDocumentCount();
      const result = await indexCorpus();
      const afterCount = await getDocumentCount();
      
      res.json({
        success: true,
        indexed: result.indexed,
        errors: result.errors,
        totalDocuments: afterCount,
        wasEmpty: beforeCount === 0
      });
    } catch (error: any) {
      console.error("[RAG] Index error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // GET /api/v2/rag/status - Get RAG status
  app.get("/api/v2/rag/status", async (req, res) => {
    try {
      const { getDocumentCount, isRagAvailable } = await import('./v2/rag-service');
      const count = await getDocumentCount();
      const available = isRagAvailable();
      
      res.json({
        available,
        indexed: count > 0,
        documentCount: count,
        message: available 
          ? (count > 0 ? "RAG ready" : "RAG available but not indexed") 
          : "OPENAI_API_KEY required for RAG"
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // POST /api/v2/rag/search - Search RAG (for testing)
  app.post("/api/v2/rag/search", async (req, res) => {
    try {
      const { query, limit, threshold } = req.body;
      
      if (!query) {
        return res.status(400).json({ error: "Query required" });
      }
      
      const { searchRag } = await import('./v2/rag-service');
      const result = await searchRag(query, { limit, threshold });
      
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // GET /api/v2/admin/methodology-report - Get methodology validation report
  app.get("/api/v2/admin/methodology-report", async (req, res) => {
    try {
      const { generateMethodologyReport } = await import('./v2/methodology-export');
      const report = generateMethodologyReport();
      res.json(report);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // GET /api/v2/admin/epic-flow - Get EPIC flow logic as markdown
  app.get("/api/v2/admin/epic-flow", async (req, res) => {
    try {
      const { generateEpicFlowMarkdown } = await import('./v2/methodology-export');
      const markdown = generateEpicFlowMarkdown();
      res.type('text/markdown').send(markdown);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // GET /api/v2/admin/reference-answers - Get all reference answers
  app.get("/api/v2/admin/reference-answers", async (req, res) => {
    try {
      const { getAllReferenceAnswersGrouped, getReferenceAnswers } = await import('./v2/reference-answers');
      const { techniqueId, signal, grouped } = req.query;
      
      if (grouped === 'true') {
        const answers = getAllReferenceAnswersGrouped();
        res.json(answers);
      } else {
        const answers = getReferenceAnswers(
          techniqueId as string | undefined, 
          signal as string | undefined
        );
        res.json(answers);
      }
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // DELETE /api/v2/admin/reference-answers/:id - Delete a reference answer
  app.delete("/api/v2/admin/reference-answers/:id", async (req, res) => {
    try {
      const { deleteReferenceAnswer } = await import('./v2/reference-answers');
      const success = deleteReferenceAnswer(req.params.id);
      if (success) {
        res.json({ success: true });
      } else {
        res.status(404).json({ error: "Reference answer not found" });
      }
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // GET /api/v2/admin/misclassification-report - Voortschrijdend inzicht report
  // Shows where AI detection differs from expert labels (learning opportunities)
  app.get("/api/v2/admin/misclassification-report", async (req, res) => {
    try {
      const { generateMisclassificationReport, getCorrections } = await import('./v2/reference-answers');
      const { getUnresolvedConflicts, getConflictStats } = await import('./v2/config-consistency');
      
      const report = generateMisclassificationReport();
      const corrections = getCorrections();
      const unresolvedConflicts = getUnresolvedConflicts();
      const conflictStats = getConflictStats();
      
      res.json({
        ...report,
        recentCorrections: corrections.slice(-10).reverse(),
        configConflicts: {
          unresolved: unresolvedConflicts,
          stats: conflictStats,
        },
        description: "Dit rapport toont waar de AI detectie afwijkt van de expert labels. " +
          "Config conflicts tonen waar de config files aangepast moeten worden (voortschrijdend inzicht)."
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // GET /api/v2/admin/config-conflicts - List all config conflicts
  app.get("/api/v2/admin/config-conflicts", async (req, res) => {
    try {
      const { getAllConflicts, getUnresolvedConflicts, getConflictStats } = await import('./v2/config-consistency');
      const { resolved } = req.query;
      
      const conflicts = resolved === 'false' ? getUnresolvedConflicts() : getAllConflicts();
      const stats = getConflictStats();
      
      res.json({ conflicts, stats });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // POST /api/v2/admin/config-conflicts/:id/resolve - Mark a conflict as resolved
  app.post("/api/v2/admin/config-conflicts/:id/resolve", async (req, res) => {
    try {
      const { resolveConflict } = await import('./v2/config-consistency');
      const { resolvedBy } = req.body;
      
      const success = resolveConflict(req.params.id, resolvedBy || 'Hugo');
      if (success) {
        res.json({ success: true, message: 'Conflict marked as resolved' });
      } else {
        res.status(404).json({ error: 'Conflict not found' });
      }
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // GET /api/v2/admin/config-conflicts/:id/patch - Get suggested config patch
  app.get("/api/v2/admin/config-conflicts/:id/patch", async (req, res) => {
    try {
      const { generateConfigPatch } = await import('./v2/config-consistency');
      const patch = generateConfigPatch(req.params.id);
      
      if (patch) {
        res.json(patch);
      } else {
        res.status(404).json({ error: 'Conflict not found or no patch available' });
      }
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // POST /api/v2/admin/config-conflicts/:id/apply - Apply patch (✓ button)
  app.post("/api/v2/admin/config-conflicts/:id/apply", async (req, res) => {
    try {
      const { applyConfigPatch } = await import('./v2/config-consistency');
      const result = applyConfigPatch(req.params.id);
      
      if (result.success) {
        res.json(result);
      } else {
        res.status(400).json({ error: result.message });
      }
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // POST /api/v2/admin/config-conflicts/:id/reject - Reject patch (✗ button)
  app.post("/api/v2/admin/config-conflicts/:id/reject", async (req, res) => {
    try {
      const { rejectPatch } = await import('./v2/config-consistency');
      const success = rejectPatch(req.params.id);
      
      if (success) {
        res.json({ success: true, message: 'Patch afgewezen' });
      } else {
        res.status(404).json({ error: 'Conflict not found' });
      }
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ============================================================
  // GOLDEN STANDARD MODE ENDPOINTS
  // Hugo (trainer) plays seller, AI plays customer
  // ============================================================

  // File-based storage for golden standard sessions (persistent)
  interface GoldenSession {
    id: string;
    techniqueId: string;
    techniqueName: string;
    conversationHistory: Array<{ role: 'seller' | 'customer'; content: string; signal?: string }>;
    persona: any;
    context: any;
    createdAt: string;
    trainerName?: string;
  }
  
  const GOLDEN_SESSIONS_PATH = path.join(process.cwd(), "data", "golden_sessions.json");
  
  function loadGoldenSessions(): Record<string, GoldenSession> {
    try {
      if (fs.existsSync(GOLDEN_SESSIONS_PATH)) {
        return JSON.parse(fs.readFileSync(GOLDEN_SESSIONS_PATH, "utf-8"));
      }
    } catch (e) {
      console.error("[golden-sessions] Error loading sessions:", e);
    }
    return {};
  }
  
  function saveGoldenSession(session: GoldenSession): void {
    const dir = path.dirname(GOLDEN_SESSIONS_PATH);
