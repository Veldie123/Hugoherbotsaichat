import { useState, useRef, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
// ARCHIVED: AppLayout removed - minimal V2 shell without navigation chrome
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { 
  Send, 
  ArrowLeft, 
  Loader2,
  User,
  Bot,
  AlertCircle,
  CheckCircle,
  XCircle,
  RotateCcw,
  Crown,
  Save,
  ChevronRight,
  ChevronDown,
  Check,
  X,
  Phone,
  Flag,
  MessageSquare,
  Copy,
  Info,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { PhoneCallModal } from "@/components/phone-call-modal";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface Technique {
  id: string;
  nummer: string;
  naam: string;
  fase: string;
}

interface TechniquePhase {
  fase: number;
  naam: string;
  technieken: Technique[];
}

interface ValidatorDebugInfo {
  mode: string;
  initialValidation: {
    label: string;
    confidence: number;
    reasoning: string;
    violations?: string[];
  };
  finalValidation?: {
    label: string;
    confidence: number;
    reasoning: string;
    violations?: string[];
  };
  repairAttempts: number;
  wasRepaired: boolean;
  configSectionsUsed: string[];
}

interface MessageDebug {
  persona?: {
    name?: string;
    behavior_style?: string;
    buying_clock_stage?: string;
    experience_level?: string;
    difficulty_level?: string;
  };
  attitude?: string | null;
  signal?: string | null;
  sampledAttitude?: string | null;
  expectedMoves?: string[];
  detectorPatterns?: string[];
  promptsUsed?: {
    systemPrompt: string;
    userPrompt: string;
  };
  context?: {
    sector?: string;
    product?: string;
    klant_type?: string;
    verkoopkanaal?: string;
    isComplete?: boolean;
    turnNumber?: number;
    phase?: number;
    techniqueId?: string;
  };
  attitudeConfig?: {
    id?: string;
    naam?: string;
    signalen?: string[];
  };
  customerDynamics?: {
    rapport: number;
    valueTension: number;
    commitReadiness: number;
  };
  epicPhase?: 'explore' | 'probe' | 'impact' | 'commit';
  evaluationQuality?: 'goed' | 'bijna' | 'niet';
  dynamicsLevels?: {
    rapport: string;
    valueTension: string;
    commitReadiness: string;
  };
  validatorInfo?: ValidatorDebugInfo;
}

interface Message {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  signal?: string;
  evaluation?: {
    detected: boolean;
    moveId: string | null;
    moveLabel: string | null;
    score: number;
    feedback: string;
    allExpected?: Array<{ id: string; label: string }>;
  };
  selectedTechnique?: string;
  selectedTechniqueName?: string;
  debug?: MessageDebug;
  matchStatus?: "match" | "mismatch" | "unknown";
  saved?: boolean;
}

interface SessionState {
  technique: string;
  mode: string;
  phase: number;
  turns: number;
  score: number;
  contextComplete: boolean;
}

const buyingClockToDisplay: Record<string, string> = {
  situation_as_is: "situation_as_is (00u–06u)",
  field_of_tension: "field_of_tension (06u–08u)",
  market_research: "market_research (08u–11u)",
  hesitation: "hesitation (11u–12u)",
  decision: "decision (12u)"
};

const difficultyToDisplay: Record<string, string> = {
  onbewuste_onkunde: "onbewuste_onkunde (1/4)",
  bewuste_onkunde: "bewuste_onkunde (2/4)",
  bewuste_kunde: "bewuste_kunde (3/4)",
  onbewuste_kunde: "onbewuste_kunde (4/4)"
};

export default function RoleplayV2Page() {
  const [, navigate] = useLocation();
  const params = useParams<{ techniqueId?: string }>();
  const { toast } = useToast();
  
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [sessionState, setSessionState] = useState<SessionState | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [expertMode, setExpertMode] = useState(false);
  const [selectedTechniqueForTurn, setSelectedTechniqueForTurn] = useState<string>("");
  const [expandedMessageIndex, setExpandedMessageIndex] = useState<number | null>(null);
  
  const [feedbackLineId, setFeedbackLineId] = useState<string | null>(null);
  const [isPhoneCallOpen, setIsPhoneCallOpen] = useState(false);
  const [feedbackComment, setFeedbackComment] = useState("");
  const [isSubmittingFeedback, setIsSubmittingFeedback] = useState(false);
  const [confirmedLines, setConfirmedLines] = useState<Set<string>>(new Set());
  const [rejectedLines, setRejectedLines] = useState<Record<string, string>>({});
  const [debriefMessage, setDebriefMessage] = useState<string | null>(null);
  const [isEndingSession, setIsEndingSession] = useState(false);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const techniquesQuery = useQuery<TechniquePhase[]>({
    queryKey: ['/api/v2/techniques'],
  });

  const allTechniques = techniquesQuery.data?.flatMap(phase => 
    phase.technieken.map(t => ({
      ...t,
      phaseNaam: phase.naam
    }))
  ) || [];

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  useEffect(() => {
    const techniqueId = params.techniqueId || "2.1";
    startSession(techniqueId);
  }, []);

  const getTechniqueName = (techniqueId: string): string => {
    const technique = allTechniques.find(t => t.nummer === techniqueId);
    return technique?.naam || techniqueId;
  };

  const startSession = async (techniqueId: string, useExpertMode: boolean = false) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await fetch("/api/v2/session/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ techniqueId, expertMode: useExpertMode }),
      });
      
      if (!response.ok) {
        throw new Error("Failed to start session");
      }
      
      const data = await response.json();
      setSessionId(data.sessionId);
      setSessionState(data.state);
      
      setMessages([{
        id: `msg-${Date.now()}`,
        role: "assistant",
        content: data.message,
        signal: data.signal,
        debug: data.debug,
      }]);
    } catch (err) {
      setError("Kon sessie niet starten");
      toast({
        title: "Fout",
        description: "Kon sessie niet starten",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const calculateMatchStatus = (
    selectedTechnique: string,
    expectedMoves?: string[]
  ): "match" | "mismatch" | "unknown" => {
    if (!expectedMoves || expectedMoves.length === 0) return "unknown";
    const isMatch = expectedMoves.some(move => 
      move.toLowerCase().includes(selectedTechnique.toLowerCase()) ||
      selectedTechnique.toLowerCase().includes(move.split(' ')[0].toLowerCase())
    );
    return isMatch ? "match" : "mismatch";
  };

  const sendMessage = async () => {
    if (!inputValue.trim() || !sessionId || isLoading) return;
    
    const userMessage = inputValue.trim();
    const techniqueForThisTurn = expertMode ? selectedTechniqueForTurn : undefined;
    const techniqueNameForThisTurn = techniqueForThisTurn ? getTechniqueName(techniqueForThisTurn) : undefined;
    
    setInputValue("");
    setIsLoading(true);
    
    const userMsgId = `msg-${Date.now()}-user`;
    setMessages(prev => [...prev, {
      id: userMsgId,
      role: "user",
      content: userMessage,
      selectedTechnique: techniqueForThisTurn,
      selectedTechniqueName: techniqueNameForThisTurn,
    }]);
    
    try {
      const response = await fetch("/api/v2/session/message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          sessionId, 
          message: userMessage,
          debug: true,
        }),
      });
      
      if (!response.ok) {
        throw new Error("Failed to send message");
      }
      
      const data = await response.json();
      setSessionState(data.state);
      
      const responseContent = data.message.replace(/^"|"$/g, '');
      
      const expectedMoves = data.debug?.expectedMoves || 
        data.evaluation?.allExpected?.map((e: any) => e.label) || [];
      
      const matchStatus = techniqueForThisTurn 
        ? calculateMatchStatus(techniqueForThisTurn, expectedMoves)
        : undefined;
      
      setMessages(prev => prev.map(msg => 
        msg.id === userMsgId 
          ? { ...msg, matchStatus, debug: data.debug }
          : msg
      ));
      
      setMessages(prev => [...prev, {
        id: `msg-${Date.now()}-assistant`,
        role: "assistant",
        content: responseContent,
        signal: data.signal,
        evaluation: data.evaluation,
        debug: data.debug,
      }]);
      
      if (expertMode) {
        setSelectedTechniqueForTurn("");
      }
      
      inputRef.current?.focus();
    } catch (err) {
      toast({
        title: "Fout",
        description: "Kon bericht niet versturen",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const saveAsReference = async (messageIndex: number) => {
    const message = messages[messageIndex];
    if (!message || message.role !== "user" || !sessionId) return;
    
    const nextMessage = messages[messageIndex + 1];
    const detectedTechnique = nextMessage?.evaluation?.moveId || null;
    
    try {
      const response = await apiRequest("POST", "/api/v2/session/save-reference", {
        sessionId,
        techniqueId: message.selectedTechnique || params.techniqueId || "2.1",
        message: message.content,
        context: message.debug?.context,
        matchStatus: message.matchStatus,
        signal: message.debug?.signal,
        detectedTechnique,
      });
      
      const data = await response.json();
      
      setMessages(prev => prev.map((msg, idx) => 
        idx === messageIndex ? { ...msg, saved: true } : msg
      ));
      
      toast({
        title: "Opgeslagen",
        description: data.message || "Referentie-antwoord opgeslagen",
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/v2/admin/reference-answers'] });
    } catch (error) {
      toast({
        title: "Fout",
        description: "Kon referentie niet opslaan",
        variant: "destructive",
      });
    }
  };

  const toggleMessageExpansion = (index: number) => {
    if (!expertMode) return;
    setExpandedMessageIndex(prev => prev === index ? null : index);
    setFeedbackLineId(null);
    setFeedbackComment("");
  };

  const openInlineFeedback = (lineId: string) => {
    setFeedbackLineId(lineId);
    setFeedbackComment(rejectedLines[lineId] || "");
  };

  const closeInlineFeedback = () => {
    setFeedbackLineId(null);
    setFeedbackComment("");
  };

  const submitInlineFeedback = async (messageIndex: number, feedbackType: "customer" | "evaluation") => {
    if (!sessionId || !feedbackComment.trim()) return;
    
    const message = messages[messageIndex];
    if (!message) return;
    
    setIsSubmittingFeedback(true);
    
    try {
      const conversationHistory = messages.map((msg) => ({
        role: msg.role as 'user' | 'assistant' | 'system',
        content: msg.content,
        signal: msg.signal || undefined
      }));
      
      if (feedbackType === "customer") {
        const response = await apiRequest("POST", "/api/v2/session/flag-customer-response", {
          sessionId,
          turnNumber: messageIndex,
          customerMessage: message.content,
          customerSignal: message.signal || 'unknown',
          currentPhase: sessionState?.phase || 2,
          techniqueId: params.techniqueId || "2.1",
          expertComment: feedbackComment,
          context: {
            sector: message.debug?.context?.sector,
            product: message.debug?.context?.product,
            klantType: message.debug?.context?.klant_type,
            persona: message.debug?.persona
          },
          conversationHistory
        });
        
        const data = await response.json();
        toast({
          title: "Feedback opgeslagen",
          description: data.message || `${data.conflictsFound} conflict(en) aangemaakt`,
        });
      } else {
        const response = await apiRequest("POST", "/api/v2/session/flag-evaluation", {
          sessionId,
          turnNumber: messageIndex,
          evaluationFeedback: message.evaluation?.feedback,
          evaluationDetected: message.evaluation?.detected,
          evaluationScore: message.evaluation?.score,
          expectedMoves: message.evaluation?.allExpected?.map((e: any) => e.label) || [],
          currentPhase: sessionState?.phase || 2,
          techniqueId: params.techniqueId || "2.1",
          expertComment: feedbackComment,
          context: {
            sector: message.debug?.context?.sector,
            product: message.debug?.context?.product,
            klantType: message.debug?.context?.klant_type,
            persona: message.debug?.persona
          },
          conversationHistory
        });
        
        const data = await response.json();
        toast({
          title: "Feedback opgeslagen",
          description: data.message || `${data.conflictsFound} conflict(en) aangemaakt`,
        });
      }
      
      if (feedbackLineId) {
        // Mutual exclusion: remove from confirmed if rejecting
        setConfirmedLines(prev => {
          const newSet = new Set(prev);
          newSet.delete(feedbackLineId);
          return newSet;
        });
        setRejectedLines(prev => ({
          ...prev,
          [feedbackLineId]: feedbackComment
        }));
      }
      closeInlineFeedback();
      queryClient.invalidateQueries({ queryKey: ['/api/v2/admin/conflicts'] });
    } catch (error) {
      toast({
        title: "Fout",
        description: "Kon feedback niet opslaan",
        variant: "destructive",
      });
    } finally {
      setIsSubmittingFeedback(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      if (expertMode && sessionState?.mode === "ROLEPLAY" && !selectedTechniqueForTurn) {
        toast({
          title: "Selecteer techniek",
          description: "Kies eerst welke techniek je toepast",
          variant: "destructive",
        });
        return;
      }
      sendMessage();
    }
  };

  const resetSession = async (clearContext: boolean = false) => {
    const techniqueId = params.techniqueId || "2.1";
    
    setIsLoading(true);
    setMessages([]);
    setSessionId(null);
    setSessionState(null);
    setExpandedMessageIndex(null);
    setSelectedTechniqueForTurn("");
    setFeedbackLineId(null);
    setFeedbackComment("");
    setConfirmedLines(new Set());
    setRejectedLines({});
    setDebriefMessage(null);
    
    try {
      const response = await fetch("/api/v2/session/reset", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionId: sessionId,
          techniqueId,
          expertMode,
          clearContext
        }),
      });
      
      if (!response.ok) {
        throw new Error("Failed to reset session");
      }
      
      const data = await response.json();
      
      setSessionId(data.sessionId);
      setSessionState({
        mode: data.mode,
        technique: getTechniqueName(techniqueId),
        phase: 1,
        turns: 0,
        score: 0,
        contextComplete: data.contextComplete
      });
      
      setMessages([{
        id: `msg-${Date.now()}`,
        role: "assistant",
        content: data.message,
        signal: data.signal,
        debug: data.debug,
      }]);
      
      toast({
        title: clearContext ? "Context gereset" : "Sessie gereset",
        description: clearContext 
          ? "Context gewist - de coach zal opnieuw vragen naar sector, product, etc."
          : "Sessie herstart met bestaande context.",
      });
    } catch (error) {
      console.error("Reset error:", error);
      toast({
        title: "Fout",
        description: "Kon sessie niet resetten",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const endSessionWithDebrief = async () => {
    if (!sessionId) return;
    
    setIsEndingSession(true);
    
    try {
      const response = await apiRequest("POST", "/api/v2/session/end", { sessionId });
      const data = await response.json();
      
      setDebriefMessage(data.message || data.debrief || "Sessie beëindigd.");
      setSessionState(prev => prev ? { 
        ...prev, 
        mode: "DEBRIEF",
        score: data.analytics?.avgScore ?? prev.score 
      } : null);
      
      toast({
        title: "Sessie beëindigd",
        description: "Bekijk hieronder de feedback van Hugo.",
      });
    } catch (error) {
      console.error("End session error:", error);
      toast({
        title: "Fout",
        description: "Kon sessie niet beëindigen",
        variant: "destructive",
      });
    } finally {
      setIsEndingSession(false);
    }
  };

  const toggleExpertMode = (enabled: boolean) => {
    setExpertMode(enabled);
    setSelectedTechniqueForTurn("");
    setExpandedMessageIndex(null);
    setFeedbackLineId(null);
    setFeedbackComment("");
    setConfirmedLines(new Set());
    setRejectedLines({});
    setDebriefMessage(null);
    
    const techniqueId = params.techniqueId || "2.1";
    setMessages([]);
    setSessionId(null);
    setSessionState(null);
    startSession(techniqueId, enabled);
    
    toast({
      title: enabled ? "Expert Opname Modus Aan" : "Expert Modus Uit",
      description: enabled 
        ? "Sessie herstart met Expert Opname actief - debug info beschikbaar."
        : "Sessie herstart in normale oefenmodus.",
    });
  };

  const copyFullConversation = () => {
    const lines: string[] = [];
    
    lines.push("=== V2 ROLEPLAY SESSIE EXPORT ===");
    lines.push(`Sessie ID: ${sessionId || "onbekend"}`);
    lines.push(`Techniek: ${sessionState?.technique || "onbekend"}`);
    lines.push(`Mode: ${sessionState?.mode || "onbekend"}`);
    lines.push(`Totaal turns: ${sessionState?.turns || 0}`);
    lines.push(`Score: ${sessionState?.score || 0}`);
    lines.push(`Expert Mode: ${expertMode ? "Ja" : "Nee"}`);
    lines.push("");
    lines.push("=== GESPREK ===");
    lines.push("");
    
    messages.forEach((msg, index) => {
      const speaker = msg.role === "user" ? "VERKOPER" : msg.role === "assistant" ? "KLANT" : "SYSTEEM";
      lines.push(`--- Turn ${index + 1} [${speaker}] ---`);
      lines.push(msg.content);
      
      if (msg.selectedTechniqueName) {
        lines.push(`  [Geselecteerde techniek: ${msg.selectedTechnique} - ${msg.selectedTechniqueName}]`);
      }
      
      if (msg.evaluation) {
        lines.push("");
        lines.push("  [EVALUATIE]");
        lines.push(`    Gedetecteerd: ${msg.evaluation.detected ? "Ja" : "Nee"}`);
        if (msg.evaluation.moveId) {
          lines.push(`    Techniek: ${msg.evaluation.moveId} - ${msg.evaluation.moveLabel || ""}`);
        }
        lines.push(`    Score: ${msg.evaluation.score}`);
        if (msg.evaluation.feedback) {
          lines.push(`    Feedback: ${msg.evaluation.feedback}`);
        }
        if (msg.matchStatus) {
          lines.push(`    Match status: ${msg.matchStatus}`);
        }
      }
      
      if (msg.debug) {
        const debug = msg.debug;
        lines.push("");
        lines.push("  [DEBUG INFO]");
        
        if (debug.context) {
          lines.push(`    Context: sector=${debug.context.sector || "?"}, product=${debug.context.product || "?"}, turn=${debug.context.turnNumber}, fase=${debug.context.phase}`);
        }
        if (debug.epicPhase) {
          lines.push(`    EPIC fase: ${debug.epicPhase}`);
        }
        if (debug.evaluationQuality) {
          lines.push(`    Evaluatie kwaliteit: ${debug.evaluationQuality}`);
        }
        if (debug.sampledAttitude) {
          lines.push(`    Klant houding: ${debug.sampledAttitude}`);
        }
        if (debug.attitude) {
          lines.push(`    Attitude: ${debug.attitude}`);
        }
        if (debug.signal) {
          lines.push(`    Signaal: ${debug.signal}`);
        }
        if (debug.persona) {
          lines.push(`    Persona: ${debug.persona.name || "?"}, style=${debug.persona.behavior_style || "?"}, koopklok=${debug.persona.buying_clock_stage || "?"}`);
        }
        if (debug.customerDynamics) {
          lines.push(`    Dynamiek: rapport=${debug.customerDynamics.rapport}, valueTension=${debug.customerDynamics.valueTension}, commitReadiness=${debug.customerDynamics.commitReadiness}`);
        }
        if (debug.expectedMoves && debug.expectedMoves.length > 0) {
          lines.push(`    Verwachte moves: ${debug.expectedMoves.join(", ")}`);
        }
      }
      
      lines.push("");
    });
    
    if (debriefMessage) {
      lines.push("=== DEBRIEF ===");
      lines.push(debriefMessage);
      lines.push("");
    }
    
    lines.push("=== EINDE EXPORT ===");
    
    navigator.clipboard.writeText(lines.join("\n")).then(() => {
      toast({
        title: "Gekopieerd",
        description: "Volledig gesprek met debug info naar klembord gekopieerd.",
      });
    }).catch(() => {
      toast({
        title: "Fout",
        description: "Kon niet naar klembord kopiëren",
        variant: "destructive",
      });
    });
  };

  const confirmLine = (lineId: string) => {
    // Mutual exclusion: remove from rejected if confirming
    setRejectedLines(prev => {
      const { [lineId]: _, ...rest } = prev;
      return rest;
    });
    setConfirmedLines(prev => {
      const newSet = new Set(prev);
      newSet.add(lineId);
      return newSet;
    });
    toast({ title: "Bevestigd", description: "Dit item is gemarkeerd als correct." });
  };

  const renderDebugLine = (
    lineId: string,
    label: string,
    value: string | null | undefined,
    messageIndex: number,
    feedbackType: "customer" | "evaluation"
  ) => {
    if (!value) return null;
    
    const isOpen = feedbackLineId === lineId;
    const isConfirmed = confirmedLines.has(lineId);
    const isRejected = lineId in rejectedLines;
    
    return (
      <div key={lineId} className="space-y-2">
        <div className="flex items-center justify-between gap-2 py-1">
          <span className="text-base">
            <span className="text-muted-foreground">{label}:</span>{" "}
            <span className="font-medium">{value}</span>
          </span>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className={`h-12 w-12 ${
                isConfirmed 
                  ? "bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300" 
                  : "text-green-600 hover:bg-green-100 dark:hover:bg-green-900"
              }`}
              onClick={(e) => {
                e.stopPropagation();
                confirmLine(lineId);
              }}
              aria-label="Dit is correct"
              data-testid={`button-confirm-${lineId}`}
            >
              {isConfirmed ? (
                <CheckCircle className="w-6 h-6" />
              ) : (
                <Check className="w-6 h-6" />
              )}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className={`h-12 w-12 ${
                isRejected 
                  ? "bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300" 
                  : "text-red-600 hover:bg-red-100 dark:hover:bg-red-900"
              }`}
              onClick={(e) => {
                e.stopPropagation();
                if (isOpen) {
                  closeInlineFeedback();
                } else {
                  openInlineFeedback(lineId);
                }
              }}
              aria-label={isRejected ? "Feedback bekijken/bewerken" : "Dit is fout"}
              data-testid={`button-wrong-${lineId}`}
            >
              {isRejected ? (
                <XCircle className="w-6 h-6" />
              ) : (
                <X className="w-6 h-6" />
              )}
            </Button>
          </div>
        </div>
        
        {isOpen && (
          <div className="pl-2 border-l-2 border-red-300 space-y-2" onClick={(e) => e.stopPropagation()}>
            <Textarea
              placeholder="Leg uit wat er fout ging..."
              value={feedbackComment}
              onChange={(e) => setFeedbackComment(e.target.value)}
              className="min-h-[80px] text-base"
              data-testid={`textarea-feedback-${lineId}`}
            />
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={closeInlineFeedback}
                className="h-12 text-base px-4"
                data-testid={`button-cancel-${lineId}`}
              >
                Annuleren
              </Button>
              <Button
                onClick={() => submitInlineFeedback(messageIndex, feedbackType)}
                disabled={!feedbackComment.trim() || isSubmittingFeedback}
                className="h-12 text-base px-4"
                data-testid={`button-submit-${lineId}`}
              >
                {isSubmittingFeedback ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : (
                  <Send className="w-4 h-4 mr-2" />
                )}
                Verstuur
              </Button>
            </div>
          </div>
        )}
      </div>
    );
  };

  const renderInlineDebugPanel = (msg: Message, index: number) => {
    const debug = msg.debug;
    const isExpanded = expandedMessageIndex === index;
    
    return (
      <Collapsible open={isExpanded} onOpenChange={() => toggleMessageExpansion(index)}>
        <CollapsibleTrigger asChild>
          <Button
            variant="ghost"
            size="sm"
            className="h-10 px-3 text-muted-foreground hover:text-foreground"
            aria-label={isExpanded ? "Debug info verbergen" : "Debug info tonen"}
            data-testid={`button-toggle-debug-${index}`}
          >
            {isExpanded ? (
              <ChevronDown className="w-4 h-4 mr-2" />
            ) : (
              <ChevronRight className="w-4 h-4 mr-2" />
            )}
            Debug Info
          </Button>
        </CollapsibleTrigger>
        
        <CollapsibleContent>
          <Card className="mt-2 p-4 bg-muted/30 border-dashed space-y-3">
            {msg.role === "assistant" && renderDebugLine(
              `signal-${index}`,
              "Klant Signaal",
              debug?.signal || msg.signal,
              index,
              "customer"
            )}
            
            {msg.evaluation && msg.evaluation.detected && renderDebugLine(
              `detected-${index}`,
              "Gedetecteerde techniek",
              `${msg.evaluation.moveLabel} (+${msg.evaluation.score})`,
              index,
              "evaluation"
            )}
            
            {msg.selectedTechnique && renderDebugLine(
              `choice-${index}`,
              "Jouw keuze",
              `${msg.selectedTechnique} - ${msg.selectedTechniqueName}`,
              index,
              "evaluation"
            )}
            
            {msg.role === "user" && msg.debug?.expectedMoves && msg.debug.expectedMoves.length > 0 && (
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Expected moves:</p>
                {msg.debug.expectedMoves.map((move, moveIdx) => 
                  renderDebugLine(
                    `expected-${index}-${moveIdx}`,
                    "",
                    move,
                    index,
                    "evaluation"
                  )
                )}
              </div>
            )}
            
            {msg.role === "assistant" && debug?.expectedMoves && debug.expectedMoves.length > 0 && (
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Verwachte volgende actie:</p>
                {debug.expectedMoves.map((move, moveIdx) => 
                  renderDebugLine(
                    `expected-${index}-${moveIdx}`,
                    "",
                    move,
                    index,
                    "evaluation"
                  )
                )}
              </div>
            )}
            
            {debug?.persona && (
              <div className="pt-2 border-t border-dashed">
                <p className="text-sm font-medium text-muted-foreground mb-2">Persona</p>
                <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
                  {debug.persona.name && (
                    <>
                      <span className="text-muted-foreground">Naam:</span>
                      <span>{debug.persona.name}</span>
                    </>
                  )}
                  {debug.persona.behavior_style && (
                    <>
                      <span className="text-muted-foreground">Gedragsstijl:</span>
                      <span>{debug.persona.behavior_style}</span>
                    </>
                  )}
                  {debug.persona.buying_clock_stage && (
                    <>
                      <span className="text-muted-foreground">Koopklok:</span>
                      <span>{buyingClockToDisplay[debug.persona.buying_clock_stage] || debug.persona.buying_clock_stage}</span>
                    </>
                  )}
                  {debug.persona.difficulty_level && (
                    <>
                      <span className="text-muted-foreground">Moeilijkheid:</span>
                      <span>{difficultyToDisplay[debug.persona.difficulty_level] || debug.persona.difficulty_level}</span>
                    </>
                  )}
                </div>
              </div>
            )}
            
            {debug?.context && (
              <div className="pt-2 border-t border-dashed">
                <p className="text-sm font-medium text-muted-foreground mb-2">Context</p>
                <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
                  {debug.context.sector && (
                    <>
                      <span className="text-muted-foreground">Sector:</span>
                      <span>{debug.context.sector}</span>
                    </>
                  )}
                  {debug.context.product && (
                    <>
                      <span className="text-muted-foreground">Product:</span>
                      <span>{debug.context.product}</span>
                    </>
                  )}
                  {debug.context.klant_type && (
                    <>
                      <span className="text-muted-foreground">Klant type:</span>
                      <span>{debug.context.klant_type}</span>
                    </>
                  )}
                  {debug.context.phase !== undefined && (
                    <>
                      <span className="text-muted-foreground">Fase:</span>
                      <span>{debug.context.phase}</span>
                    </>
                  )}
                </div>
              </div>
            )}
            
            {debug?.customerDynamics && (
              <div className="pt-2 border-t border-dashed">
                <p className="text-sm font-medium text-muted-foreground mb-2">Customer Dynamics</p>
                <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
                  <span className="text-muted-foreground">Rapport:</span>
                  <span>
                    {(debug.customerDynamics.rapport * 100).toFixed(0)}%
                    <span className="text-xs text-muted-foreground ml-1">
                      ({debug.dynamicsLevels?.rapport || 'midden'})
                    </span>
                  </span>
                  <span className="text-muted-foreground">Value Tension:</span>
                  <span>
                    {(debug.customerDynamics.valueTension * 100).toFixed(0)}%
                    <span className="text-xs text-muted-foreground ml-1">
                      ({debug.dynamicsLevels?.valueTension || 'midden'})
                    </span>
                  </span>
                  <span className="text-muted-foreground">Commit Readiness:</span>
                  <span>
                    {(debug.customerDynamics.commitReadiness * 100).toFixed(0)}%
                    <span className="text-xs text-muted-foreground ml-1">
                      ({debug.dynamicsLevels?.commitReadiness || 'midden'})
                    </span>
                  </span>
                </div>
              </div>
            )}
            
            {(debug?.epicPhase || debug?.evaluationQuality || debug?.sampledAttitude) && (
              <div className="pt-2 border-t border-dashed">
                <p className="text-sm font-medium text-muted-foreground mb-2">AI Beslissingen</p>
                <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
                  {debug.epicPhase && (
                    <>
                      <span className="text-muted-foreground">EPIC Fase:</span>
                      <span className="capitalize">{debug.epicPhase}</span>
                    </>
                  )}
                  {debug.evaluationQuality && (
                    <>
                      <span className="text-muted-foreground">Evaluatie:</span>
                      <span className={
                        debug.evaluationQuality === 'goed' ? 'text-green-600' :
                        debug.evaluationQuality === 'bijna' ? 'text-amber-600' :
                        'text-red-600'
                      }>{debug.evaluationQuality}</span>
                    </>
                  )}
                  {debug.sampledAttitude && debug.attitude && debug.sampledAttitude !== debug.attitude && (
                    <>
                      <span className="text-muted-foreground">Houding correctie:</span>
                      <span className="text-amber-600">
                        {debug.sampledAttitude} → {debug.attitude}
                      </span>
                    </>
                  )}
                </div>
              </div>
            )}
            
            {debug?.validatorInfo && (
              <div className="pt-2 border-t border-dashed">
                <p className="text-sm font-medium text-muted-foreground mb-2">
                  Validator Results
                  {debug.validatorInfo.wasRepaired && (
                    <Badge className="ml-2 bg-amber-500/10 text-amber-600 border-amber-500/30">
                      REPAIRED
                    </Badge>
                  )}
                </p>
                <div className="space-y-2 text-sm">
                  <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                    <span className="text-muted-foreground">Mode:</span>
                    <span>{debug.validatorInfo.mode}</span>
                    <span className="text-muted-foreground">Initial Label:</span>
                    <span className={
                      debug.validatorInfo.initialValidation.label === 'VALID' ? 'text-green-600' :
                      debug.validatorInfo.initialValidation.label === 'WRONG_MODE' ? 'text-red-600' :
                      debug.validatorInfo.initialValidation.label === 'TOO_DIRECTIVE' ? 'text-amber-600' :
                      debug.validatorInfo.initialValidation.label === 'MIXED_SIGNALS' ? 'text-orange-600' :
                      'text-muted-foreground'
                    }>
                      {debug.validatorInfo.initialValidation.label} 
                      <span className="text-xs text-muted-foreground ml-1">
                        ({(debug.validatorInfo.initialValidation.confidence * 100).toFixed(0)}%)
                      </span>
                    </span>
                    <span className="text-muted-foreground">Repair Attempts:</span>
                    <span>{debug.validatorInfo.repairAttempts}</span>
                  </div>
                  
                  <div className="mt-2">
                    <p className="text-xs font-medium text-muted-foreground mb-1">Initial Reasoning:</p>
                    <pre className="text-xs bg-background p-2 rounded border overflow-auto max-h-32 whitespace-pre-wrap">
                      {debug.validatorInfo.initialValidation.reasoning}
                    </pre>
                  </div>
                  
                  {debug.validatorInfo.initialValidation.violations && debug.validatorInfo.initialValidation.violations.length > 0 && (
                    <div className="mt-2">
                      <p className="text-xs font-medium text-red-600 mb-1">Violations:</p>
                      <ul className="text-xs space-y-1">
                        {debug.validatorInfo.initialValidation.violations.map((v, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <span className="text-red-500">•</span>
                            <span>{v}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  {debug.validatorInfo.finalValidation && (
                    <div className="mt-2 pt-2 border-t border-dashed">
                      <p className="text-xs font-medium text-muted-foreground mb-1">
                        Final Label (after repair):
                        <span className={`ml-2 ${
                          debug.validatorInfo.finalValidation.label === 'VALID' ? 'text-green-600' : 'text-amber-600'
                        }`}>
                          {debug.validatorInfo.finalValidation.label}
                        </span>
                      </p>
                      <pre className="text-xs bg-background p-2 rounded border overflow-auto max-h-32 whitespace-pre-wrap">
                        {debug.validatorInfo.finalValidation.reasoning}
                      </pre>
                    </div>
                  )}
                  
                  {debug.validatorInfo.configSectionsUsed.length > 0 && (
                    <div className="mt-2">
                      <p className="text-xs font-medium text-muted-foreground mb-1">Config Sections Used:</p>
                      <div className="flex flex-wrap gap-1">
                        {debug.validatorInfo.configSectionsUsed.map((section, i) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {section}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
            
            {debug?.promptsUsed && (
              <div className="pt-2 border-t border-dashed">
                <p className="text-sm font-medium text-muted-foreground mb-2">AI Prompt (volledige instructie)</p>
                <div className="space-y-3">
                  {debug.promptsUsed.systemPrompt && (
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-1">System Prompt:</p>
                      <pre className="text-xs bg-background p-3 rounded border overflow-auto max-h-64 whitespace-pre-wrap">
                        {debug.promptsUsed.systemPrompt}
                      </pre>
                    </div>
                  )}
                  {debug.promptsUsed.userPrompt && (
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-1">User Prompt:</p>
                      <pre className="text-xs bg-background p-3 rounded border overflow-auto max-h-64 whitespace-pre-wrap">
                        {debug.promptsUsed.userPrompt}
                      </pre>
                    </div>
                  )}
                </div>
              </div>
            )}
            
            {msg.role === "user" && (
              <div className="pt-3 border-t border-dashed">
                {msg.saved ? (
                  <Badge className="text-sm bg-green-500/10 text-green-600 border-green-500/30 py-2 px-3">
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Opgeslagen als referentie
                  </Badge>
                ) : (
                  <Button
                    variant="outline"
                    onClick={(e) => {
                      e.stopPropagation();
                      saveAsReference(index);
                    }}
                    className="h-12 text-base px-4"
                    data-testid={`button-save-reference-${index}`}
                  >
                    <Save className="w-5 h-5 mr-2" />
                    Opslaan als referentie
                  </Button>
                )}
              </div>
            )}
          </Card>
        </CollapsibleContent>
      </Collapsible>
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="flex flex-col h-screen">
        <div className="flex items-center justify-between p-4 border-b gap-4">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => navigate("/epic-flow")}
              data-testid="button-back"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="font-semibold text-foreground" data-testid="text-session-title">
                V2 Roleplay - {sessionState?.technique || "Loading..."}
              </h1>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs">
                  {sessionState?.mode || "..."}
                </Badge>
                <Badge variant="secondary" className="text-xs">
                  Turn {sessionState?.turns || 0}
                </Badge>
                <Badge className="text-xs bg-hh-primary">
                  Score: {sessionState?.score || 0}
                </Badge>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsPhoneCallOpen(true)}
              disabled={!sessionId}
              className="text-hh-primary hover:bg-hh-primary/10"
              data-testid="button-start-call"
              title="Start audio gesprek"
            >
              <Phone className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-2">
              <Switch 
                id="expert-mode"
                checked={expertMode}
                onCheckedChange={toggleExpertMode}
                data-testid="switch-expert-mode"
              />
              <Label htmlFor="expert-mode" className="flex items-center gap-1 text-sm cursor-pointer">
                <Crown className={`w-4 h-4 ${expertMode ? "text-amber-500" : "text-muted-foreground"}`} />
                Expert Opname
              </Label>
            </div>
            {expertMode && (
              <>
                <Badge variant="outline" className="bg-amber-500/10 text-amber-600 border-amber-500/30">
                  Opname Actief
                </Badge>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={copyFullConversation}
                  disabled={messages.length === 0}
                  title="Kopieer volledig gesprek + debug info"
                  data-testid="button-copy-conversation"
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </>
            )}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="outline" 
                  size="sm"
                  disabled={isLoading}
                  data-testid="button-reset-session"
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Opnieuw beginnen
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem 
                  onClick={() => resetSession(false)}
                  data-testid="menu-reset-session"
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Herstart sessie (bewaar context)
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => resetSession(true)}
                  data-testid="menu-reset-context"
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  Reset context (opnieuw invullen)
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button
              variant="default"
              size="sm"
              onClick={endSessionWithDebrief}
              disabled={isLoading || isEndingSession || !sessionId || sessionState?.mode === "DEBRIEF"}
              className="bg-hh-secondary hover:bg-hh-secondary/90"
              data-testid="button-end-session"
            >
              {isEndingSession ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Flag className="w-4 h-4 mr-2" />
              )}
              Afsluiten met Feedback
            </Button>
          </div>
        </div>

        <div className="flex-1 flex overflow-hidden">
          <div className="flex-1 flex flex-col">
            <ScrollArea className="flex-1 p-4" ref={scrollRef}>
              <div className="max-w-2xl mx-auto space-y-4">
                {expertMode && (
                  <Card className="p-4 bg-amber-500/5 border-amber-500/20">
                    <div className="flex items-start gap-3">
                      <Crown className="w-5 h-5 text-amber-500 mt-0.5" />
                      <div className="text-sm">
                        <p className="font-medium text-amber-600">Expert Opname Modus</p>
                        <p className="text-muted-foreground">
                          Selecteer voor elk bericht welke techniek je toepast. 
                          Klik op een bericht om debug-info te zien.
                        </p>
                      </div>
                    </div>
                  </Card>
                )}

                {messages.map((msg, index) => (
                  <div 
                    key={msg.id}
                    className={`flex gap-3 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    {msg.role === "assistant" && (
                      <div className="flex-shrink-0 flex flex-col items-center gap-1">
                        <div className="w-8 h-8 rounded-full bg-hh-primary/10 flex items-center justify-center">
                          <Bot className="w-4 h-4 text-hh-primary" />
                        </div>
                        {expertMode && msg.debug?.promptsUsed && (
                          <Dialog>
                            <DialogTrigger asChild>
                              <button 
                                className="w-6 h-6 rounded-full bg-blue-500/20 hover:bg-blue-500/30 flex items-center justify-center transition-colors"
                                title="Bekijk AI Prompt"
                                data-testid={`button-view-prompt-${index}`}
                              >
                                <span className="text-[10px] font-bold text-blue-600">AI</span>
                              </button>
                            </DialogTrigger>
                            <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden flex flex-col">
                              <DialogHeader>
                                <DialogTitle className="flex items-center gap-2">
                                  <Info className="w-5 h-5 text-blue-500" />
                                  AI Prompt voor dit antwoord
                                </DialogTitle>
                              </DialogHeader>
                              <div className="flex-1 overflow-auto space-y-4">
                                <div>
                                  <h4 className="font-semibold text-sm text-muted-foreground mb-2">System Prompt:</h4>
                                  <pre className="text-xs bg-muted p-3 rounded-md overflow-x-auto whitespace-pre-wrap max-h-[300px] overflow-y-auto">
                                    {msg.debug.promptsUsed.systemPrompt}
                                  </pre>
                                </div>
                                <div>
                                  <h4 className="font-semibold text-sm text-muted-foreground mb-2">User Prompt:</h4>
                                  <pre className="text-xs bg-muted p-3 rounded-md overflow-x-auto whitespace-pre-wrap">
                                    {msg.debug.promptsUsed.userPrompt}
                                  </pre>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                        )}
                      </div>
                    )}
                    
                    <div className={`max-w-[80%] space-y-2`}>
                      <Card 
                        className={`p-3 ${expertMode ? "cursor-pointer" : ""} transition-all ${
                          msg.role === "user" 
                            ? "bg-hh-primary text-primary-foreground" 
                            : "bg-card"
                        } ${expertMode && expandedMessageIndex === index ? "ring-2 ring-amber-500" : ""}`}
                        onClick={() => toggleMessageExpansion(index)}
                        data-testid={`card-message-${index}`}
                      >
                        <p className="whitespace-pre-wrap">{msg.content}</p>
                      </Card>
                      
                      {expertMode && renderInlineDebugPanel(msg, index)}
                    </div>
                    
                    {msg.role === "user" && (
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-hh-secondary/10 flex items-center justify-center">
                        <User className="w-4 h-4 text-hh-secondary" />
                      </div>
                    )}
                  </div>
                ))}
                
                {isLoading && (
                  <div className="flex gap-3 justify-start">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-hh-primary/10 flex items-center justify-center">
                      <Bot className="w-4 h-4 text-hh-primary" />
                    </div>
                    <Card className="p-3 bg-card">
                      <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                    </Card>
                  </div>
                )}

                {debriefMessage && (
                  <Card className="p-6 bg-hh-primary/5 border-hh-primary/20" data-testid="card-debrief">
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0 w-10 h-10 rounded-full bg-hh-primary/20 flex items-center justify-center">
                        <MessageSquare className="w-5 h-5 text-hh-primary" />
                      </div>
                      <div className="flex-1 space-y-3">
                        <div className="flex items-center justify-between">
                          <h3 className="font-semibold text-lg text-hh-primary">Feedback van Hugo</h3>
                          <Badge className="bg-hh-primary">Score: {sessionState?.score || 0}</Badge>
                        </div>
                        <div className="prose prose-sm dark:prose-invert max-w-none">
                          <p className="whitespace-pre-wrap text-foreground">{debriefMessage}</p>
                        </div>
                        <div className="flex gap-2 pt-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setDebriefMessage(null);
                              resetSession(false);
                            }}
                            data-testid="button-restart-after-debrief"
                          >
                            <RotateCcw className="w-4 h-4 mr-2" />
                            Opnieuw oefenen
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => navigate("/epic-flow")}
                            data-testid="button-back-to-epic-flow"
                          >
                            <ArrowLeft className="w-4 h-4 mr-2" />
                            Terug naar overzicht
                          </Button>
                        </div>
                      </div>
                    </div>
                  </Card>
                )}
              </div>
            </ScrollArea>

            {!debriefMessage && (
              <div className="p-4 border-t space-y-3">
                {expertMode && sessionState?.mode === "ROLEPLAY" && (
                  <div className="max-w-2xl mx-auto">
                    <Label className="text-sm text-muted-foreground mb-2 block">
                      Welke techniek pas je toe?
                    </Label>
                    <Select 
                      value={selectedTechniqueForTurn} 
                      onValueChange={setSelectedTechniqueForTurn}
                    >
                      <SelectTrigger className="w-full" data-testid="select-technique-trigger">
                        <SelectValue placeholder="Selecteer techniek voordat je verzendt..." />
                      </SelectTrigger>
                      <SelectContent className="max-h-80" data-testid="select-technique-content">
                        {techniquesQuery.data?.map((phase) => (
                          <SelectGroup key={phase.fase}>
                            <SelectLabel className="text-sm font-semibold">
                              Fase {phase.fase}: {phase.naam}
                            </SelectLabel>
                            {phase.technieken.map((technique) => (
                              <SelectItem 
                                key={technique.nummer} 
                                value={technique.nummer}
                                data-testid={`select-technique-option-${technique.nummer}`}
                              >
                                {technique.nummer} - {technique.naam}
                              </SelectItem>
                            ))}
                          </SelectGroup>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
                
                <div className="max-w-2xl mx-auto flex gap-2">
                  <Input
                    ref={inputRef}
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder={
                      sessionState?.mode === "CONTEXT_GATHERING" 
                        ? "Antwoord op de vraag..." 
                        : expertMode && sessionState?.mode === "ROLEPLAY" && !selectedTechniqueForTurn
                          ? "Selecteer eerst een techniek..."
                          : "Typ je verkoopboodschap..."
                    }
                    disabled={isLoading}
                    data-testid="input-message"
                  />
                  <Button
                    onClick={sendMessage}
                    disabled={
                      !inputValue.trim() || 
                      isLoading || 
                      (expertMode && sessionState?.mode === "ROLEPLAY" && !selectedTechniqueForTurn)
                    }
                    data-testid="button-send"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>

        {error && (
          <div className="absolute bottom-20 left-1/2 -translate-x-1/2">
            <Card className="p-3 bg-destructive/10 border-destructive">
              <p className="text-sm text-destructive">{error}</p>
            </Card>
          </div>
        )}
      </div>

      <PhoneCallModal
        isOpen={isPhoneCallOpen}
        onClose={() => setIsPhoneCallOpen(false)}
        techniqueId={params.techniqueId || "2.1"}
        techniqueName={sessionState?.technique || "Techniek"}
        sessionId={sessionId}
        onSendMessage={async (text: string) => {
          if (!sessionId) return "";
          
          const userMessage: Message = {
            id: `user-${Date.now()}`,
            role: "user",
            content: text,
          };
          setMessages((prev) => [...prev, userMessage]);
          
          try {
            const response = await apiRequest("POST", `/api/v2/session/${sessionId}/message`, {
              userMessage: text,
            });
            
            const data = await response.json();
            
            if (data.sessionState) {
              setSessionState(data.sessionState);
            }
            
            const assistantMessage: Message = {
              id: `assistant-${Date.now()}`,
              role: "assistant",
              content: data.assistantMessage || data.coachMessage || "",
            };
            setMessages((prev) => [...prev, assistantMessage]);
            
            return assistantMessage.content;
          } catch (error) {
            console.error("Error sending message:", error);
            return "";
          }
        }}
      />
    </div>
  );
}
