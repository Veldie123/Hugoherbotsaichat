import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
// ARCHIVED: AppLayout removed - minimal V2 shell without navigation chrome
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  AlertTriangle, 
  ArrowLeft, 
  Check, 
  X,
  Loader2, 
  FileCode, 
  Eye,
  AlertCircle,
  CheckCircle2,
  MessageSquare,
  User,
  Bot,
  ChevronDown,
  ChevronRight,
  ArrowUpDown,
  Clock,
  Quote
} from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ScrollArea } from "@/components/ui/scroll-area";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface SessionContext {
  sessionId: string;
  turnNumber: number;
  customerMessage: string;
  customerSignal: string;
  currentPhase: number;
  expertComment: string;
  context?: {
    sector?: string;
    product?: string;
    klantType?: string;
    persona?: {
      name?: string;
      behavior_style?: string;
      buying_clock_stage?: string;
      experience_level?: string;
      difficulty_level?: string;
    };
  };
  conversationHistory?: Array<{
    role: 'user' | 'assistant' | 'system';
    content: string;
    signal?: string;
  }>;
}

interface ConflictFinding {
  id: string;
  correctionId: string;
  severity: 'high' | 'medium' | 'low';
  configFile: string;
  techniqueId: string;
  conflictType: 'pattern_overlap' | 'missing_definition' | 'conceptual_ambiguity' | 'detector_mismatch';
  description: string;
  suggestedChange?: string;
  createdAt?: string;
  resolvedAt?: string;
  resolvedBy?: string;
  sessionContext?: SessionContext;
}

interface ConflictStats {
  total: number;
  unresolved: number;
  resolved: number;
  bySeverity: {
    high: number;
    medium: number;
    low: number;
  };
  byType: Record<string, number>;
}

interface ConflictsResponse {
  conflicts: ConflictFinding[];
  stats: ConflictStats;
}

interface PatchResponse {
  conflictId: string;
  configFile: string;
  currentValue: unknown;
  suggestedValue: unknown;
  patchInstructions: string;
}

const conflictTypeLabels: Record<string, string> = {
  'pattern_overlap': 'Pattern Overlap',
  'missing_definition': 'Missing Definition',
  'conceptual_ambiguity': 'Conceptual Ambiguity',
  'detector_mismatch': 'Detector Mismatch',
};

type SortOrder = 'newest' | 'oldest';

export default function AdminConflictsPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [showResolved, setShowResolved] = useState(false);
  const [sortOrder, setSortOrder] = useState<SortOrder>('newest');
  const [selectedConflictId, setSelectedConflictId] = useState<string | null>(null);
  const [patchDialogOpen, setPatchDialogOpen] = useState(false);

  const { data, isLoading, error } = useQuery<ConflictsResponse>({
    queryKey: ["/api/v2/admin/config-conflicts", showResolved ? "" : "?resolved=false"],
  });

  const { data: patchData, isLoading: patchLoading } = useQuery<PatchResponse>({
    queryKey: ["/api/v2/admin/config-conflicts", selectedConflictId, "patch"],
    enabled: !!selectedConflictId && patchDialogOpen,
  });

  // Apply patch mutation (✓ button)
  const applyMutation = useMutation({
    mutationFn: async (conflictId: string) => {
      const response = await apiRequest("POST", `/api/v2/admin/config-conflicts/${conflictId}/apply`, {});
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/v2/admin/config-conflicts"] });
      toast({
        title: "Patch toegepast",
        description: data.message || "Config is bijgewerkt.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Fout",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Reject patch mutation (✗ button)
  const rejectMutation = useMutation({
    mutationFn: async (conflictId: string) => {
      const response = await apiRequest("POST", `/api/v2/admin/config-conflicts/${conflictId}/reject`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/v2/admin/config-conflicts"] });
      toast({
        title: "Patch afgewezen",
        description: "Conflict is gemarkeerd als afgehandeld.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Fout",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'high':
        return <Badge variant="destructive" data-testid={`badge-severity-high`}>High</Badge>;
      case 'medium':
        return <Badge variant="secondary" data-testid={`badge-severity-medium`}>Medium</Badge>;
      case 'low':
        return <Badge variant="outline" data-testid={`badge-severity-low`}>Low</Badge>;
      default:
        return <Badge>{severity}</Badge>;
    }
  };

  const handleViewPatch = (conflictId: string) => {
    setSelectedConflictId(conflictId);
    setPatchDialogOpen(true);
  };

  const handleApply = (conflictId: string) => {
    applyMutation.mutate(conflictId);
  };

  const handleReject = (conflictId: string) => {
    rejectMutation.mutate(conflictId);
  };

  const rawConflicts = data?.conflicts || [];
  const stats = data?.stats;
  
  // Sort conflicts by createdAt
  const conflicts = [...rawConflicts].sort((a, b) => {
    const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
    const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
    return sortOrder === 'newest' ? dateB - dateA : dateA - dateB;
  });
  
  const formatDateTime = (dateStr?: string) => {
    if (!dateStr) return 'Onbekende datum';
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return 'Onbekende datum';
    return date.toLocaleString('nl-NL', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="p-6 max-w-7xl mx-auto">
        <div className="mb-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/")}
            className="mb-4"
            data-testid="button-back-home"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Terug naar home
          </Button>
          
          <h1 className="text-3xl font-normal mb-2" data-testid="text-page-title">Config Conflicts Review</h1>
          <p className="text-hh-muted">Bekijk en beheer configuratie conflicten die handmatig opgelost moeten worden</p>
        </div>

        <Alert className="mb-6 border-blue-500 bg-blue-50 dark:bg-blue-950/20" data-testid="alert-info">
          <AlertCircle className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-800 dark:text-blue-200">
            Klik op de groene ✓ om een patch toe te passen, of op de rode ✗ om af te wijzen.
          </AlertDescription>
        </Alert>

        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <Card data-testid="stat-total">
              <CardContent className="pt-6">
                <div className="text-2xl font-bold">{stats.total}</div>
                <p className="text-xs text-hh-muted">Totaal conflicten</p>
              </CardContent>
            </Card>
            <Card data-testid="stat-unresolved">
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-destructive">{stats.unresolved}</div>
                <p className="text-xs text-hh-muted">Onopgelost</p>
              </CardContent>
            </Card>
            <Card data-testid="stat-high">
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-red-600">{stats.bySeverity?.high || 0}</div>
                <p className="text-xs text-hh-muted">High severity</p>
              </CardContent>
            </Card>
            <Card data-testid="stat-resolved">
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-green-600">{stats.resolved}</div>
                <p className="text-xs text-hh-muted">Opgelost</p>
              </CardContent>
            </Card>
          </div>
        )}

        <div className="flex items-center gap-3 mb-6 flex-wrap">
          <Switch
            id="show-resolved"
            checked={showResolved}
            onCheckedChange={setShowResolved}
            data-testid="switch-show-resolved"
          />
          <Label htmlFor="show-resolved">Toon ook opgeloste conflicten</Label>
          
          <div className="ml-auto flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSortOrder(sortOrder === 'newest' ? 'oldest' : 'newest')}
              className="gap-2"
              data-testid="button-sort-order"
            >
              <ArrowUpDown className="w-4 h-4" />
              {sortOrder === 'newest' ? 'Nieuwste eerst' : 'Oudste eerst'}
            </Button>
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-hh-primary" />
          </div>
        ) : error ? (
          <Card>
            <CardContent className="py-12 text-center">
              <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
              <p className="text-destructive">Fout bij laden van conflicten</p>
            </CardContent>
          </Card>
        ) : conflicts.length === 0 ? (
          <Card data-testid="card-empty-state">
            <CardContent className="py-12 text-center">
              <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">Geen conflicten gevonden</h3>
              <p className="text-hh-muted">
                {showResolved 
                  ? "Er zijn geen configuratie conflicten geregistreerd."
                  : "Alle conflicten zijn opgelost. Schakel de toggle in om opgeloste conflicten te zien."}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {conflicts.map((conflict) => (
              <Card 
                key={conflict.id} 
                className={conflict.resolvedAt ? "opacity-60" : ""}
                data-testid={`card-conflict-${conflict.id}`}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-4 flex-wrap">
                    <div className="flex items-center gap-2 flex-wrap">
                      {getSeverityBadge(conflict.severity)}
                      <Badge variant="outline" data-testid={`badge-type-${conflict.id}`}>
                        {conflictTypeLabels[conflict.conflictType] || conflict.conflictType}
                      </Badge>
                      <Badge variant="secondary" data-testid={`badge-technique-${conflict.id}`}>
                        {conflict.techniqueId}
                      </Badge>
                      {conflict.resolvedAt && (
                        <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100">
                          Opgelost
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-4 text-xs text-hh-muted flex-wrap">
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span data-testid={`text-created-${conflict.id}`}>{formatDateTime(conflict.createdAt)}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <FileCode className="w-3 h-3" />
                        <span data-testid={`text-configfile-${conflict.id}`}>{conflict.configFile}</span>
                      </div>
                    </div>
                  </div>
                  <CardTitle className="text-base mt-2" data-testid={`text-description-${conflict.id}`}>
                    {conflict.description}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {conflict.suggestedChange && (
                    <div className="bg-muted/50 rounded-md p-3 mb-4">
                      <p className="text-sm font-medium mb-1">Voorgestelde aanpassing:</p>
                      <p className="text-sm text-hh-muted" data-testid={`text-suggestion-${conflict.id}`}>
                        {conflict.suggestedChange}
                      </p>
                    </div>
                  )}
                  
                  {conflict.resolvedAt && conflict.resolvedBy && (
                    <p className="text-xs text-hh-muted mb-4">
                      Opgelost door {conflict.resolvedBy} op {new Date(conflict.resolvedAt).toLocaleDateString('nl-NL')}
                    </p>
                  )}

                  {conflict.sessionContext && (
                    <Collapsible className="mb-4">
                      <CollapsibleTrigger className="flex items-center gap-2 text-sm font-medium hover:underline group" data-testid={`trigger-conversation-${conflict.id}`}>
                        <MessageSquare className="w-4 h-4" />
                        <span>Bekijk rollenspel gesprek</span>
                        <ChevronRight className="w-4 h-4 transition-transform group-data-[state=open]:rotate-90" />
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3">
                        <Card className="bg-muted/30">
                          <CardContent className="pt-4 space-y-3">
                            <div className="grid grid-cols-2 gap-2 text-xs mb-3">
                              <div>
                                <span className="text-muted-foreground">Fase:</span>{" "}
                                <Badge variant="outline">{conflict.sessionContext.currentPhase}</Badge>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Signaal:</span>{" "}
                                <Badge variant="secondary">{conflict.sessionContext.customerSignal}</Badge>
                              </div>
                              {conflict.sessionContext.context?.sector && (
                                <div>
                                  <span className="text-muted-foreground">Sector:</span>{" "}
                                  {conflict.sessionContext.context.sector}
                                </div>
                              )}
                              {conflict.sessionContext.context?.product && (
                                <div>
                                  <span className="text-muted-foreground">Product:</span>{" "}
                                  {conflict.sessionContext.context.product}
                                </div>
                              )}
                              {conflict.sessionContext.context?.persona?.behavior_style && (
                                <div className="col-span-2">
                                  <span className="text-muted-foreground">Persona:</span>{" "}
                                  {conflict.sessionContext.context.persona.behavior_style} / {conflict.sessionContext.context.persona.buying_clock_stage}
                                </div>
                              )}
                            </div>
                            
                            {conflict.sessionContext.conversationHistory && conflict.sessionContext.conversationHistory.length > 0 && (
                              <div className="border-t pt-3">
                                <p className="text-xs font-medium mb-2 text-muted-foreground">Gesprek:</p>
                                <ScrollArea className="h-64 border rounded-md bg-background p-2">
                                  <div className="space-y-2">
                                    {conflict.sessionContext.conversationHistory.map((msg, idx) => {
                                      const isFlaggedMessage = idx === conflict.sessionContext?.turnNumber;
                                      return (
                                        <div 
                                          key={idx}
                                          className={`flex gap-2 ${msg.role === 'user' ? 'justify-end' : 'justify-start'} ${
                                            isFlaggedMessage ? 'relative' : ''
                                          }`}
                                        >
                                          {isFlaggedMessage && (
                                            <div className="absolute -left-1 top-0 bottom-0 w-1 bg-red-500 rounded-full" />
                                          )}
                                          {msg.role === 'assistant' && (
                                            <div className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center ${
                                              isFlaggedMessage ? 'bg-red-500/20' : 'bg-hh-primary/10'
                                            }`}>
                                              <Bot className={`w-3 h-3 ${isFlaggedMessage ? 'text-red-600' : 'text-hh-primary'}`} />
                                            </div>
                                          )}
                                          <div className={`max-w-[80%] ${msg.role === 'system' ? 'w-full' : ''}`}>
                                            <Card className={`p-2 text-xs ${
                                              isFlaggedMessage
                                                ? 'bg-red-100 dark:bg-red-900/30 border-2 border-red-500 ring-2 ring-red-200 dark:ring-red-800'
                                                : msg.role === 'user' 
                                                  ? 'bg-hh-primary text-primary-foreground' 
                                                  : msg.role === 'system'
                                                  ? 'bg-muted/50 italic'
                                                  : 'bg-card'
                                            }`}>
                                              <p className="whitespace-pre-wrap">{msg.content}</p>
                                              {isFlaggedMessage && (
                                                <div className="mt-2 pt-2 border-t border-red-300 dark:border-red-700 space-y-2">
                                                  <div className="flex items-center gap-1 text-red-600 dark:text-red-400">
                                                    <AlertTriangle className="w-3 h-3" />
                                                    <span className="font-medium">Geflagd door Hugo</span>
                                                  </div>
                                                  {conflict.sessionContext?.expertComment && (
                                                    <div className="bg-amber-50 dark:bg-amber-950/50 border border-amber-300 dark:border-amber-700 rounded p-2">
                                                      <div className="flex items-start gap-2">
                                                        <Quote className="w-3 h-3 mt-0.5 text-amber-600 dark:text-amber-400 flex-shrink-0" />
                                                        <p className="text-xs italic text-amber-800 dark:text-amber-200">
                                                          {conflict.sessionContext.expertComment}
                                                        </p>
                                                      </div>
                                                    </div>
                                                  )}
                                                </div>
                                              )}
                                            </Card>
                                            {msg.signal && (
                                              <Badge variant={isFlaggedMessage ? "destructive" : "outline"} className="text-xs mt-1">
                                                {msg.signal}
                                              </Badge>
                                            )}
                                          </div>
                                          {msg.role === 'user' && (
                                            <div className="flex-shrink-0 w-6 h-6 rounded-full bg-hh-secondary/10 flex items-center justify-center">
                                              <User className="w-3 h-3 text-hh-secondary" />
                                            </div>
                                          )}
                                        </div>
                                      );
                                    })}
                                  </div>
                                </ScrollArea>
                              </div>
                            )}
                            
                            {(!conflict.sessionContext.conversationHistory || conflict.sessionContext.conversationHistory.length === 0) && (
                              <div className="border-t pt-3">
                                <p className="text-xs font-medium mb-2 text-muted-foreground">Klant bericht:</p>
                                <Card className="p-2 text-xs bg-red-100 dark:bg-red-900/30 border-2 border-red-500">
                                  <p className="whitespace-pre-wrap">{conflict.sessionContext.customerMessage}</p>
                                  <div className="mt-2 pt-2 border-t border-red-300 dark:border-red-700 space-y-2">
                                    <div className="flex items-center gap-1 text-red-600 dark:text-red-400">
                                      <AlertTriangle className="w-3 h-3" />
                                      <span className="font-medium">Geflagd door Hugo</span>
                                    </div>
                                    {conflict.sessionContext.expertComment && (
                                      <div className="bg-amber-50 dark:bg-amber-950/50 border border-amber-300 dark:border-amber-700 rounded p-2">
                                        <div className="flex items-start gap-2">
                                          <Quote className="w-3 h-3 mt-0.5 text-amber-600 dark:text-amber-400 flex-shrink-0" />
                                          <p className="text-xs italic text-amber-800 dark:text-amber-200">
                                            {conflict.sessionContext.expertComment}
                                          </p>
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                </Card>
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      </CollapsibleContent>
                    </Collapsible>
                  )}

                  <div className="flex items-center gap-3 flex-wrap">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleViewPatch(conflict.id)}
                      data-testid={`button-view-patch-${conflict.id}`}
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      Bekijk
                    </Button>
                    
                    {!conflict.resolvedAt && (
                      <div className="flex items-center gap-2 ml-auto">
                        <span className="text-sm text-muted-foreground mr-2">Accepteer patch?</span>
                        <Button
                          size="icon"
                          className="h-12 w-12 rounded-full bg-green-600 hover:bg-green-700 text-white"
                          onClick={() => handleApply(conflict.id)}
                          disabled={applyMutation.isPending || rejectMutation.isPending}
                          data-testid={`button-apply-${conflict.id}`}
                        >
                          {applyMutation.isPending ? (
                            <Loader2 className="w-6 h-6 animate-spin" />
                          ) : (
                            <Check className="w-6 h-6" strokeWidth={3} />
                          )}
                        </Button>
                        <Button
                          size="icon"
                          className="h-12 w-12 rounded-full bg-red-600 hover:bg-red-700 text-white"
                          onClick={() => handleReject(conflict.id)}
                          disabled={applyMutation.isPending || rejectMutation.isPending}
                          data-testid={`button-reject-${conflict.id}`}
                        >
                          {rejectMutation.isPending ? (
                            <Loader2 className="w-6 h-6 animate-spin" />
                          ) : (
                            <X className="w-6 h-6" strokeWidth={3} />
                          )}
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        <Dialog open={patchDialogOpen} onOpenChange={setPatchDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-auto" data-testid="dialog-patch">
            <DialogHeader>
              <DialogTitle>Config Patch Details</DialogTitle>
              <DialogDescription>
                Bekijk de voorgestelde wijziging voor dit conflict
              </DialogDescription>
            </DialogHeader>
            
            {patchLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin" />
              </div>
            ) : patchData ? (
              <div className="space-y-4">
                <div>
                  <Label className="text-sm font-medium">Config File</Label>
                  <p className="text-sm text-hh-muted" data-testid="text-patch-file">{patchData.configFile}</p>
                </div>
                
                {patchData.patchInstructions && (
                  <div>
                    <Label className="text-sm font-medium">Instructies</Label>
                    <div className="bg-muted rounded-md p-3 mt-1">
                      <pre className="text-sm whitespace-pre-wrap" data-testid="text-patch-instructions">
                        {patchData.patchInstructions}
                      </pre>
                    </div>
                  </div>
                )}

                {patchData.currentValue !== undefined && (
                  <div>
                    <Label className="text-sm font-medium">Huidige waarde</Label>
                    <div className="bg-red-50 dark:bg-red-950/20 rounded-md p-3 mt-1 border border-red-200 dark:border-red-800">
                      <pre className="text-sm whitespace-pre-wrap text-red-800 dark:text-red-200" data-testid="text-patch-current">
                        {JSON.stringify(patchData.currentValue, null, 2)}
                      </pre>
                    </div>
                  </div>
                )}

                {patchData.suggestedValue !== undefined && (
                  <div>
                    <Label className="text-sm font-medium">Voorgestelde waarde</Label>
                    <div className="bg-green-50 dark:bg-green-950/20 rounded-md p-3 mt-1 border border-green-200 dark:border-green-800">
                      <pre className="text-sm whitespace-pre-wrap text-green-800 dark:text-green-200" data-testid="text-patch-suggested">
                        {JSON.stringify(patchData.suggestedValue, null, 2)}
                      </pre>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-8 text-hh-muted">
                Geen patch informatie beschikbaar voor dit conflict
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
