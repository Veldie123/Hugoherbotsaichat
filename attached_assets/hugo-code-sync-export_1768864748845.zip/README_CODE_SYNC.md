# Hugo Platform Code Sync Export

**Export datum:** 2025-01-19
**Bron:** Master Replit (V2 Engine volledig)

## Wat zit erin?

### Server V2 Engine (`server/v2/`)
| Bestand | Regels | Beschrijving |
|---------|--------|--------------|
| `roleplay-engine.ts` | 58604 | Volledige V2 roleplay engine |
| `coach-engine.ts` | 40368 | Coach chat modus |
| `context_engine.ts` | 36333 | Context gathering engine |
| `config-consistency.ts` | 28209 | **Golden Standard conflicts analyzer** |
| `evaluator.ts` | 24657 | Techniek detectie en scoring |
| `prompt-context.ts` | 18908 | Shared prompt builders |
| `response-repair.ts` | 9896 | Validation repair loop |
| `reference-answers.ts` | 7173 | **Golden Standard opslag** |
| `response-validator.ts` | 6851 | Response validation |
| `rag-service.ts` | 5783 | RAG semantic search |

### Server Helpers (`server/`)
| Bestand | Beschrijving |
|---------|--------------|
| `ssot-loader.ts` | Laadt technieken_index.json + overlays |
| `hugo-persona-loader.ts` | Laadt Hugo persona config |
| `routes-golden-standard-section.ts` | **Routes om toe te voegen aan routes.ts** |

### Client Pages (`client/src/pages/`)
| Bestand | Beschrijving |
|---------|--------------|
| `roleplay-v2.tsx` | **Expert Mode + Debug panels** |
| `admin-conflicts.tsx` | **Admin conflicts review page** |

### Config Files (`config/`)
| Map/Bestand | Beschrijving |
|-------------|--------------|
| `ssot/` | technieken_index.json, evaluator_overlay.json, coach_overlay.json, hugo_persona.json |
| `prompts/` | coach_richtlijn.json, context_gathering.json, roleplay_klant.json, etc. |
| `detectors.json` | Techniek detector patterns |
| `klant_houdingen.json` | Klant attitudes config |
| `persona_templates.json` | Persona behavior templates |

### Data Files (`data/`)
| Bestand | Beschrijving |
|---------|--------------|
| `reference_answers.json` | **Opgeslagen golden standard answers** |
| `config_conflicts.json` | **Gedetecteerde config conflicten** |
| `rag/epic_rag_corpus.json` | RAG corpus (942KB) |
| `rag/documents_for_embedding.jsonl` | Embedding documents |

### Shared (`shared/`)
| Bestand | Beschrijving |
|---------|--------------|
| `schema.ts` | Drizzle database schema |

---

## Installatie Instructies

### Stap 1: Backup maken in target Replit
```bash
# Maak backup van huidige bestanden
cp -r server/v2 server/v2_backup
cp -r client/src/pages client/src/pages_backup
```

### Stap 2: Kopieer server/v2/ bestanden
Vervang ALLE bestanden in `server/v2/` met de bestanden uit deze export.

### Stap 3: Kopieer server helpers
```bash
cp server/ssot-loader.ts [target]/server/
cp server/hugo-persona-loader.ts [target]/server/
```

### Stap 4: Voeg routes toe aan routes.ts
Open `routes-golden-standard-section.ts` en kopieer de inhoud naar je `server/routes.ts`.

De routes zijn:
- `POST /api/v2/session/save-reference`
- `POST /api/v2/session/flag-customer-response`
- `POST /api/v2/session/flag-evaluation`
- `GET /api/v2/admin/reference-answers`
- `DELETE /api/v2/admin/reference-answers/:id`
- `GET /api/v2/admin/config-conflicts`
- `POST /api/v2/admin/config-conflicts/:id/resolve`
- `GET /api/v2/admin/config-conflicts/:id/patch`
- `POST /api/v2/admin/config-conflicts/:id/apply`
- `POST /api/v2/admin/config-conflicts/:id/reject`
- `POST /api/golden-standard/start`
- `POST /api/golden-standard/message`
- `POST /api/golden-standard/save-reference`
- `GET /api/golden-standard/session/:sessionId`

### Stap 5: Kopieer client pages
```bash
cp client/src/pages/roleplay-v2.tsx [target]/client/src/pages/
cp client/src/pages/admin-conflicts.tsx [target]/client/src/pages/
```

### Stap 6: Voeg route toe in App.tsx
```tsx
import AdminConflicts from "@/pages/admin-conflicts";

// In Router component:
<Route path="/admin/conflicts" component={AdminConflicts} />
```

### Stap 7: Kopieer config files
Vervang/merge de config bestanden in `config/` folder.

### Stap 8: Kopieer data files
```bash
mkdir -p data/rag
cp data/reference_answers.json [target]/data/
cp data/config_conflicts.json [target]/data/
cp data/rag/* [target]/data/rag/
```

### Stap 9: Herstart workflow
```bash
# Workflow herstarten
npm run dev
```

---

## Wat doet elk systeem?

### Golden Standard Flow
1. Expert Mode aan in roleplay-v2.tsx
2. Expert speelt roleplay, selecteert techniek per beurt
3. AI detecteert (mogelijk anders)
4. Expert klikt "Save" → `reference_answers.json`
5. Bij mismatch → `config-consistency.ts` analyseert
6. Conflicts → `config_conflicts.json`
7. Admin review op `/admin/conflicts`
8. Apply/Reject patches

### Few-Shot Learning
- `getExamplesForTechnique()` haalt golden examples
- Corrections krijgen prioriteit (edge cases)
- Examples worden in prompts geïnjecteerd
- **GEEN model fine-tuning** - in-context learning

### RAG Service
- Werkt met pgvector in PostgreSQL
- SQL functie `match_rag_documents()`
- OpenAI `text-embedding-3-small` embeddings
- Vereist OPENAI_API_KEY secret

---

## Database Vereisten

De RAG service verwacht een `match_rag_documents` SQL functie. Als deze niet bestaat:

```sql
CREATE OR REPLACE FUNCTION match_rag_documents(
  query_embedding vector(1536),
  similarity_threshold float,
  match_count int,
  filter_doc_type text DEFAULT NULL,
  filter_techniek_id text DEFAULT NULL
)
RETURNS TABLE (
  id text,
  doc_type text,
  title text,
  content text,
  techniek_id text,
  similarity float
)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    rd.id,
    rd.doc_type,
    rd.title,
    rd.content,
    rd.techniek_id,
    1 - (rd.embedding <=> query_embedding) AS similarity
  FROM rag_documents rd
  WHERE 1 - (rd.embedding <=> query_embedding) > similarity_threshold
    AND (filter_doc_type IS NULL OR rd.doc_type = filter_doc_type)
    AND (filter_techniek_id IS NULL OR rd.techniek_id = filter_techniek_id)
  ORDER BY rd.embedding <=> query_embedding
  LIMIT match_count;
END;
$$;
```

---

## Verificatie

Na installatie, test:

1. **Expert Mode**: Ga naar `/roleplay/2.1`, zet Expert Mode aan
2. **Debug Panel**: Klik op een bericht → debug info moet uitklappen
3. **Admin Conflicts**: Ga naar `/admin/conflicts` → moet laden
4. **Golden Standard routes**: Test `GET /api/v2/admin/reference-answers`

---

## Contact

Bij problemen: check de console logs en vergelijk met deze README.
